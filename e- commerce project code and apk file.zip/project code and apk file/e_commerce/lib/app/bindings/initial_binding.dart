import 'package:e_commerce/app/export.dart';


class InitialBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<StorageService>(StorageService());
    Get.put<ApiService>(ApiService());
    Get.put<CartController>(CartController()); 
    Get.put<SplashController>(SplashController());
    Get.put<LoginController>(LoginController());
    Get.put<ProductController>(ProductController()); 
   
  }
}