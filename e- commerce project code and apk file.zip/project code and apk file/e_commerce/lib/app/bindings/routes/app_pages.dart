import 'package:e_commerce/app/export.dart';


class AppPages {
  static final pages = [
    GetPage(name: AppRoutes.splash, page: () => SplashScreen()),
    GetPage(name: AppRoutes.login, page: () => LoginScreen()),
    GetPage(name: AppRoutes.products, page: () => ProductListScreen()),
    GetPage(
      name: AppRoutes.productDetails,
      page: () => ProductDetailsScreen(),
    ),
    GetPage(name: AppRoutes.cart, page: () => CartScreen()),
  ];
}