class AppRoutes {
  static const splash = '/splash';
  static const login = '/login';
  static const products = '/products';
  static const productDetails = '/product/:id';
  static const cart = '/cart';
}