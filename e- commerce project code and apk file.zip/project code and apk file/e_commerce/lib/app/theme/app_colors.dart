import 'package:e_commerce/app/export.dart';


class AppColors {
  static const Color primary = Colors.blue;
    static const Color black12 = Colors.black12;
    static const Color black87=Colors.black87;
        static const Color white70 = Colors.white70;

        static const Color white54= Colors.white54;

  static const Color black54 = Colors.black54;

  static const Color blue=Color.fromARGB(255, 40, 40, 120);
    static const Color blue2=Color.fromARGB(255, 102, 102, 178);
    static Color get borderLight => Colors.grey[400]!;
static Color get borderDark => Colors.white24;
static const Color amber = Colors.amber;

  static const Color primaryDark = Colors.blueGrey;
  static const Color accent = Colors.green;
  static const Color error = Colors.red;
  static const Color backgroundLight = Colors.white;
  static const Color backgroundDark = Color(0xFF121212);
  static const Color cardLight = Colors.white;
  static const Color cardDark = Color(0xFF1E1E1E);
  static const Color textLight = Colors.black87;
  static const Color textDark = Colors.white;
   // Shimmer colors
  static Color get shimmerBaseLight => Colors.grey[300]!;
  static Color get shimmerHighlightLight => Colors.grey[100]!;
  static Color get shimmerBaseDark => Colors.grey[800]!;
  static Color get shimmerHighlightDark => Colors.grey[600]!;
    static Color get snackbarSuccessLight => Colors.green;
  static Color get snackbarSuccessDark => Colors.green[800]!;
  static Color get snackbarErrorLight => Colors.red;
  static Color get snackbarErrorDark => Colors.red[800]!;
  static Color get snackbarInfoLight => Colors.blue;
  static Color get snackbarInfoDark => Colors.blue[800]!;
  static Color get snackbarWarningLight => Colors.orange;
  static Color get snackbarWarningDark => Colors.orange[800]!;

  static Color get snackbarTextLight => Colors.white;
  static Color get snackbarTextDark => Colors.black;

  static Color get grey => Colors.grey.shade400; 
  static const Color greyDark = Colors.grey;
  static Color get captionLight => Colors.grey.shade600;
static Color get captionDark => Colors.grey.shade400;
  static Color get captionLight2 => Colors.amber.shade600;
static Color get captionDark2 => Colors.amber.shade400;


}