import 'package:e_commerce/app/export.dart';




class AppTextStyles {
  static TextStyle get baseHeadline1 => GoogleFonts.poppins(
        fontSize: 28,
        fontWeight: FontWeight.bold,
      );
  static TextStyle get baseHeadline2 => GoogleFonts.poppins(
        fontSize: 22,
        fontWeight: FontWeight.w600,
      );
  static TextStyle get baseBodyText1 => GoogleFonts.poppins(fontSize: 16);
  static TextStyle get baseBodyText2 => GoogleFonts.poppins(fontSize: 14);
  static TextStyle get baseCaption => GoogleFonts.poppins(
        fontSize: 12,
      );
       static TextStyle get baseCaption2 => GoogleFonts.poppins(
        fontSize: 12,
      );
  static TextStyle get baseButton => GoogleFonts.poppins(
        fontSize: 16,
        fontWeight: FontWeight.w500,
      );

  static TextStyle headline1(BuildContext context) =>
      baseHeadline1.copyWith(
        fontSize: ResponsiveHelper.fontSize(context, 28),
                fontWeight: FontWeight.bold,

      );
  static TextStyle headline2(BuildContext context) =>
      baseHeadline2.copyWith(
        fontSize: ResponsiveHelper.fontSize(context, 22),
        color: Theme.of(context).brightness == Brightness.dark
          ? AppColors.backgroundLight
          : AppColors.backgroundDark,
      );
  static TextStyle bodyText1(BuildContext context) =>
      baseBodyText1.copyWith(
        fontSize: ResponsiveHelper.fontSize(context, 16),
      );
  static TextStyle bodyText2(BuildContext context) =>
      baseBodyText2.copyWith(
        fontSize: ResponsiveHelper.fontSize(context, 14),
                fontWeight: FontWeight.bold,
      );
  static TextStyle caption(BuildContext context) =>
      baseCaption.copyWith(
        fontSize: ResponsiveHelper.fontSize(context, 12),
        fontWeight: FontWeight.w600,
        color: Theme.of(context).brightness == Brightness.dark
          ? AppColors.captionDark
          : AppColors.captionLight,
      );
       static TextStyle caption2(BuildContext context) =>
      baseCaption2.copyWith(
        fontSize: ResponsiveHelper.fontSize(context, 12),
        fontWeight: FontWeight.w600,
        color: Theme.of(context).brightness == Brightness.dark
          ? AppColors.captionDark2
          : AppColors.captionLight2,
      );
  static TextStyle button(BuildContext context) =>
      baseButton.copyWith(
         color: Theme.of(context).brightness == Brightness.dark
          ? AppColors.backgroundLight
          : AppColors.backgroundDark,
        fontSize: ResponsiveHelper.fontSize(context, 16),
      );
}