import 'package:e_commerce/app/export.dart';


class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      brightness: Brightness.light,
      primaryColor: AppColors.primary,
      scaffoldBackgroundColor: AppColors.backgroundLight,
      cardColor: AppColors.cardLight,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        titleTextStyle: AppTextStyles.baseHeadline2,
        elevation: 0,
      ),
      textTheme: TextTheme(
        headlineLarge: AppTextStyles.baseHeadline1,
        headlineMedium: AppTextStyles.baseHeadline2,
        bodyLarge: AppTextStyles.baseBodyText1,
        bodyMedium: AppTextStyles.baseBodyText2,
        bodySmall: AppTextStyles.baseCaption,
        labelLarge: AppTextStyles.baseButton,
        labelSmall: AppTextStyles.baseCaption2
      ).apply(
        bodyColor: AppColors.textLight,
        displayColor: AppColors.textLight,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
  static bool isDarkMode(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark;
  }

  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      primaryColor: AppColors.primaryDark,
      scaffoldBackgroundColor: AppColors.backgroundDark,
      cardColor: AppColors.cardDark,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.primaryDark,
        foregroundColor: Colors.white,
        titleTextStyle: AppTextStyles.baseHeadline2,
        elevation: 0,
      ),
      textTheme: TextTheme(
        headlineLarge: AppTextStyles.baseHeadline1,
        headlineMedium: AppTextStyles.baseHeadline2,
        bodyLarge: AppTextStyles.baseBodyText1,
        bodyMedium: AppTextStyles.baseBodyText2,
        bodySmall: AppTextStyles.baseCaption,
        labelLarge: AppTextStyles.baseButton,
      ).apply(
        bodyColor: AppColors.textDark,
        displayColor: AppColors.textDark,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryDark,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}
