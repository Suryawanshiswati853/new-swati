import 'package:e_commerce/app/export.dart';




/// Controller for managing the shopping cart.
/// Handles add, remove, quantity updates, and persistence via SharedPreferences.
class CartController extends GetxController {
  /// Service for reading/writing cart data from SharedPreferences
  final StorageService _storage = Get.find<StorageService>();

  // ================================================================
  // Reactive state
  // ================================================================

  /// List of items currently in the cart
  RxList<CartItem> cartItems = <CartItem>[].obs;

  /// Total number of items (sum of quantities, not unique products)
  RxInt totalItems = 0.obs;

  /// Total cost of all items in the cart
  RxDouble totalAmount = 0.0.obs;

  // ================================================================
  // Lifecycle
  // ================================================================

  @override
  void onInit() {
    super.onInit();
    loadCart(); // Load persisted cart when the controller is created
  }

  // ================================================================
  // Data loading
  // ================================================================

  /// Loads the cart from SharedPreferences and updates the UI.
  /// Called once when the app starts.
  Future<void> loadCart() async {
    cartItems.value = await _storage.loadCart();
    updateTotals();
    update(); // Notify UI (GetBuilder) that cart has changed
  }

  // ================================================================
  // Calculations
  // ================================================================

  /// Recalculates total items and total amount based on current cartItems.
  /// Called after every cart modification.
  void updateTotals() {
    totalItems.value = cartItems.fold(0, (sum, item) => sum + item.quantity);
    totalAmount.value = cartItems.fold(
      0.0,
      (sum, item) => sum + (item.product.price * item.quantity),
    );
  }

  // ================================================================
  // Cart operations
  // ================================================================

  /// Adds a product to the cart.
  /// If the product already exists, increases its quantity instead of duplicating.
  Future<void> addItem(CartItem item) async {
    // Check if the product is already in the cart
    final existingIndex = cartItems.indexWhere(
      (i) => i.product.id == item.product.id,
    );
    if (existingIndex != -1) {
      // Product exists → increment quantity
      cartItems[existingIndex].quantity += item.quantity;
    } else {
      // New product → add to list
      cartItems.add(item);
    }
    await _saveAndUpdate(); // Persist and recalculate totals
  }

  /// Increases the quantity of a specific cart item by 1.
  /// Called when user taps the '+' button in the cart list.
  Future<void> incrementQuantity(int index) async {
    cartItems[index].quantity++;
    await _saveAndUpdate();
  }

  /// Decreases the quantity of a specific cart item by 1.
  /// If quantity becomes 0, removes the item entirely.
  /// Called when user taps the '-' button in the cart list.
  Future<void> decrementQuantity(int index) async {
    if (cartItems[index].quantity > 1) {
      // Still has more than 1 → just decrement
      cartItems[index].quantity--;
      await _saveAndUpdate();
    } else {
      // Quantity would become 0 → remove the item
      removeItem(index);
    }
  }

  /// Completely removes an item from the cart.
  /// Called when user taps the trash/delete icon.
  Future<void> removeItem(int index) async {
    cartItems.removeAt(index);
    await _saveAndUpdate();
  }

  /// Removes all items from the cart.
  /// Called when user taps 'Clear Cart' button.
  Future<void> clearCart() async {
    cartItems.clear();
    await _saveAndUpdate();
  }

  

  /// Saves current cart to SharedPreferences, recalculates totals, and notifies UI.
  /// Called after every cart modification to ensure persistence.
  Future<void> _saveAndUpdate() async {
    await _storage.saveCart(cartItems); // Persist to disk
    updateTotals(); // Recalculate totals
    update(); // Notify GetBuilder listeners
  }
}