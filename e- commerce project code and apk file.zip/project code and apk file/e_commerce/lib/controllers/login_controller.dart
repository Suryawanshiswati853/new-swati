import 'package:e_commerce/app/export.dart';


/// Controller for the Login screen.
/// Handles form validation, authentication, and navigation after successful login.
class LoginController extends GetxController {
  /// Service for reading/writing login status from SharedPreferences
  final StorageService _storage = Get.find<StorageService>();

  // ================================================================
  // Form controllers & state
  // ================================================================

  /// Controller for the username text field
  final TextEditingController usernameController = TextEditingController();

  /// Controller for the password text field
  final TextEditingController passwordController = TextEditingController();

  /// Global key to validate the login form
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  /// Reactive boolean indicating whether a login request is in progress.
  /// Used to disable the login button and show a loading indicator.
  RxBool isLoading = false.obs;

  

  /// Called when the controller is removed from memory.
  /// Cleans up text editing controllers to prevent memory leaks.
  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  /// (Called when the controller is closed via GetX's route management.)
  @override
  void onClose() {
    usernameController.dispose();
    passwordController.dispose();
    super.onClose();
  }

  // ================================================================
  // Authentication logic
  // ================================================================

  /// Validates user input and attempts to log in.
  /// - If validation fails, returns early.
  /// - Shows loading state while processing.
  /// - Checks credentials against static values from AppConstants.
  /// - On success: saves login status and navigates to product list.
  /// - On failure: shows an error snackbar.
  Future<void> login() async {
  // Validate the form (uses the validator functions in LoginScreen)
  if (!formKey.currentState!.validate()) return;

  // Show loading indicator
  isLoading.value = true;
  await Future.delayed(const Duration(seconds: 1)); // Simulate network delay

  // Get trimmed input values
  final username = usernameController.text.trim();
  final password = passwordController.text.trim();

  // Check credentials against static values
  if (username == AppConstants.loginUsername &&
      password == AppConstants.loginPassword) {
    // Success: persist login status
    await _storage.setLoginStatus(true);

    //  Show success snackbar
    AppSnackbar.showSuccess('Login successful');

    // Brief delay so the snackbar is visible before navigation
    await Future.delayed(const Duration(milliseconds: 500));

    // Navigate to product list
    Get.offNamed(AppRoutes.products);
  } else {
    // Failure: show error snackbar (already exists)
    AppSnackbar.showError('Invalid username or password');
  }

  // Hide loading indicator
  isLoading.value = false;
}
}