import 'dart:async';
import 'package:e_commerce/app/export.dart';




// lib/controllers/product_controller.dart

class ProductController extends GetxController {
  final ApiService _api = Get.find<ApiService>();
  final StorageService _storage = Get.find<StorageService>();

  // ---------- All products (master list) ----------
  RxList<Product> allProducts = <Product>[].obs;

  // ---------- Displayed products (filtered) ----------
  RxList<Product> displayedProducts = <Product>[].obs;

  // ---------- Loading & error states ----------
  RxBool isLoadingList = false.obs;
  RxBool isErrorList = false.obs;
  RxBool isConnected = true.obs;
  RxBool isRetrying = false.obs;

  // ---------- Category Filter ----------
  RxList<String> categories = <String>[].obs;
  RxString selectedCategory = ''.obs;
  RxBool isLoadingCategories = false.obs;

  // ---------- Search ----------
  RxString searchQuery = ''.obs;
  Timer? _debounceTimer;

  // ---------- Product Details ----------
  Rx<Product?> productDetails = Rx<Product?>(null);
  RxBool isLoadingDetails = false.obs;
  RxBool isErrorDetails = false.obs;
  RxInt detailsQuantity = 1.obs;

  // ---------- Flags ----------
  bool _isFetching = false;

  @override
  void onInit() {
    super.onInit();
    isLoadingList.value = true;
    update();
    fetchCategories();
    fetchProducts();
    _listenConnectivity();
  }

  // ---- Categories ----
  Future<void> fetchCategories() async {
    isLoadingCategories.value = true;
    try {
      final data = await _api.getCategories();
      categories.assignAll(data);
    } catch (e) {
      print('❌ Failed to load categories: $e');
    } finally {
      isLoadingCategories.value = false;
      update();
    }
  }

  // ---- Combined filter (category + search) ----
  void applyFilters() {
    // Start with the full list
    var list = allProducts.toList();

    // Category filter
    if (selectedCategory.value.isNotEmpty) {
      list = list.where((p) => p.category == selectedCategory.value).toList();
    }

    // Search filter
    if (searchQuery.value.isNotEmpty) {
      final query = searchQuery.value.toLowerCase();
      list = list.where((p) =>
          p.title.toLowerCase().contains(query) ||
          p.category.toLowerCase().contains(query) ||
          p.description.toLowerCase().contains(query)
      ).toList();
    }

    // Update displayed list
    displayedProducts.assignAll(list);
    update();
  }

  // ---- Search with debounce ----
  void filterProducts(String query) {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 500), () {
      searchQuery.value = query;
      applyFilters();
    });
  }

  // ---- Connectivity ----
  void _listenConnectivity() {
    Connectivity().onConnectivityChanged.listen((result) async {
      if (_isFetching) return;
      await Future.delayed(const Duration(milliseconds: 300));
      if (result == ConnectivityResult.none) {
        isConnected.value = false;
        isErrorList.value = true;
        isLoadingList.value = false;
        update();
        return;
      }
      fetchProducts(); // auto‑retry
    });
  }

  // ---- Fetch products ----
  Future<void> fetchProducts() async {
    if (_isFetching) return;
    _isFetching = true;
    isRetrying.value = true;

    final connResult = await Connectivity().checkConnectivity();
    if (connResult == ConnectivityResult.none) {
      isConnected.value = false;
      isErrorList.value = true;
      isLoadingList.value = false;
      isRetrying.value = false;
      _isFetching = false;
      update();
      return;
    }

    isLoadingList.value = true;
    isErrorList.value = false;
    update();

    try {
      final data = await _api.getProducts();
      allProducts.assignAll(data.map((json) => Product.fromJson(json)).toList());
      isConnected.value = true;
      //  Apply filters – this populates displayedProducts
      applyFilters();
      print('Fetched ${allProducts.length} products');
    } catch (e) {
      print(' API error: $e');
      isErrorList.value = true;
      isConnected.value = false;
    } finally {
      isLoadingList.value = false;
      isRetrying.value = false;
      _isFetching = false;
      update();
    }
  }

  Future<void> refreshProducts() => fetchProducts();

  // ---- Product Details ----
  Future<void> fetchProductDetails(int productId) async {
    isLoadingDetails.value = true;
    isErrorDetails.value = false;
    productDetails.value = null;
    detailsQuantity.value = 1;
    update();
    try {
      final data = await _api.getProduct(productId);
      productDetails.value = Product.fromJson(data);
    } catch (e) {
      isErrorDetails.value = true;
    } finally {
      isLoadingDetails.value = false;
      update();
    }
  }

  // ---- Details quantity ----
  void incrementDetailsQuantity() {
    if (detailsQuantity.value < 99) {
      detailsQuantity.value++;
      update();
    }
  }

  void decrementDetailsQuantity() {
    if (detailsQuantity.value > 1) {
      detailsQuantity.value--;
      update();
    }
  }

  // ---- Navigation ----
  void goToDetails(int productId) {
    Get.toNamed('/product/$productId');
  }

  // ---- Add to cart (list) ----
  Future<void> addToCart(Product product) async {
    final cart = await _storage.loadCart();
    final existingIndex = cart.indexWhere((item) => item.product.id == product.id);
    if (existingIndex != -1) {
      cart[existingIndex].quantity++;
    } else {
      cart.add(CartItem(product: product, quantity: 1));
    }
    await _storage.saveCart(cart);
    Get.find<CartController>().loadCart();
    AppSnackbar.showSuccess('Added to cart');
  }

  // ---- Add to cart (details) ----
  Future<void> addToCartWithQuantity(Product product, int qty) async {
    if (qty <= 0) return;
    final cart = await _storage.loadCart();
    final existingIndex = cart.indexWhere((item) => item.product.id == product.id);
    if (existingIndex != -1) {
      cart[existingIndex].quantity += qty;
    } else {
      cart.add(CartItem(product: product, quantity: qty));
    }
    await _storage.saveCart(cart);
    Get.find<CartController>().loadCart();
    detailsQuantity.value = 1;
    AppSnackbar.showSuccess('Added to cart');
  }
}
