import 'package:e_commerce/app/export.dart';

/// Controller for the Splash screen.
/// - Checks internet connectivity on startup.
/// - Listens for connectivity changes.
/// - Navigates to Login or Product List based on login status and connectivity.
class SplashController extends GetxController {
  
  /// Service for reading/writing login status from SharedPreferences
  final StorageService _storage = Get.find<StorageService>();

 

  /// Whether the device currently has internet connectivity.
  /// Updated by connectivity checks and listeners.
  bool isConnected = true;

  /// Whether the connectivity check is still in progress.
  /// Used to show a loading indicator on the splash screen.
  bool isChecking = true;

  /// Prevents multiple navigation calls when connectivity flips quickly.
  /// Set to true after the first navigation attempt.
  bool _hasNavigated = false;

 

  @override
  void onInit() {
    super.onInit();
    _checkConnectivity(); 
    _listenToConnectivity(); 
  }

  // ================================================================
  // Connectivity checks
  // ================================================================

  /// Checks the current connectivity status once.
  /// - Updates `isConnected` and `isChecking`.
  /// - If online and not already navigated, proceeds to login/product list.
  void _checkConnectivity() async {
    final result = await Connectivity().checkConnectivity();
    isConnected = (result != ConnectivityResult.none);
    isChecking = false;
    update(); // Notify GetBuilder listeners

    if (isConnected && !_hasNavigated) {
      _navigateBasedOnLogin();
    }
  }

  /// Listens for connectivity changes while the app is running.
  /// - When going from offline → online, triggers navigation if not already done.
  /// - Updates `isConnected` and notifies the UI.
  void _listenToConnectivity() {
    Connectivity().onConnectivityChanged.listen((result) {
      final wasConnected = isConnected;
      isConnected = (result != ConnectivityResult.none);
      update(); // UI rebuilds to show connection status

      // Navigate only when we regain connectivity and haven't navigated yet
      if (!wasConnected && isConnected && !_hasNavigated) {
        _navigateBasedOnLogin();
      }
    });
  }

  

  /// Called when the user taps the "Retry" button on the "No Internet" screen.
  /// Resets `isChecking` and performs a fresh connectivity check.
  void retry() {
    isChecking = true;
    update();
    _checkConnectivity();
  }

  // ================================================================
  // Navigation
  // ================================================================

  /// Navigates to the appropriate screen based on login status.
  /// - If logged in → goes to Product List.
  /// - If not logged in → goes to Login.
  /// - Waits 2 seconds (splash delay) before navigating.
  /// - Uses `_hasNavigated` to prevent duplicate navigation.
  Future<void> _navigateBasedOnLogin() async {
    if (!isConnected || _hasNavigated) return;
    _hasNavigated = true; 

    final isLoggedIn = await _storage.getLoginStatus();
    await Future.delayed(const Duration(seconds: 2)); // Splash delay

    if (isLoggedIn) {
      Get.offNamed(AppRoutes.products);
    } else {
      Get.offNamed(AppRoutes.login);
    }
  }
}