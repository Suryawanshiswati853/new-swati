class ApiConstants {
  static const String baseUrl = 'https://fakestoreapi.com';
  static const String productsEndpoint = '/products';
    static const String categoriesEndpoint = '$productsEndpoint/categories';
  static const String wishlistEndpoint = '/wishlist'; 

}