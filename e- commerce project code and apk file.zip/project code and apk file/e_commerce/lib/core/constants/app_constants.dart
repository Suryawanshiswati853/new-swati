class AppConstants {
  static const String loginUsername = 'test';
  static const String loginPassword = '123456';

  // SharedPreferences keys
  static const String keyLoginStatus = 'isLoggedIn';
  static const String keyCart = 'cart';
  static const String keyTheme = 'themeMode';
}