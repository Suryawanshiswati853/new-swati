class ImageConstants {
  // ---- Asset Images ----
  static const String loginLogo = 'assets/login.png';
   static const String appLogo = 'assets/shopping.png';

  
}