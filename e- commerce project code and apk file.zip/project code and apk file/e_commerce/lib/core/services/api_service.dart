import 'package:http/http.dart' as http;
import 'package:e_commerce/app/export.dart';





class ApiService {

// get products
  Future<List<dynamic>> getProducts() async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConstants.baseUrl}${ApiConstants.productsEndpoint}'),
      );
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load products: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to fetch products: $e');
    }
  }
  // get product by id
  Future<Map<String, dynamic>> getProduct(int id) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConstants.baseUrl}${ApiConstants.productsEndpoint}/$id'),
      );
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load product $id: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to fetch product $id: $e');
    }
  }

  // ---- GET CATEGORIES ----
  Future<List<String>> getCategories() async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConstants.baseUrl}${ApiConstants.categoriesEndpoint}'),
      );
      if (response.statusCode == 200) {
        return List<String>.from(json.decode(response.body));
      } else {
        throw Exception('Failed to load categories: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to fetch categories: $e');
    }
  }

  //  Products by category
  Future<List<dynamic>> getProductsByCategory(String category) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConstants.baseUrl}${ApiConstants.productsEndpoint}/category/$category'),
      );
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load products for category: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to fetch products for category: $e');
    }
  }
}