import '../../app/export.dart';




/// Service for persisting and retrieving app data using SharedPreferences.
/// Handles:
/// - Login status
/// - Cart contents (as JSON)
/// - Theme preference (light/dark/system)
class StorageService {
  // ================================================================
  // Login status
  // ================================================================

  /// Returns the stored login status.
  /// Defaults to `false` if no value is found.
  Future<bool> getLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(AppConstants.keyLoginStatus) ?? false;
  }

  /// Saves the login status (true = logged in, false = logged out).
  Future<void> setLoginStatus(bool status) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.keyLoginStatus, status);
  }

  /// Convenience method to log out (sets login status to false).
  Future<void> logout() async {
    await setLoginStatus(false);
  }

  
  /// Returns the raw JSON string of the cart stored in SharedPreferences.
  /// Returns `null` if no cart data exists.
  Future<String?> getCartString() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(AppConstants.keyCart);
  }

  /// Saves the cart as a raw JSON string.
  /// Used internally by `saveCart()` after encoding.
  Future<void> saveCartString(String cartJson) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.keyCart, cartJson);
  }

  
  /// Loads the cart from SharedPreferences and returns it as a list of `CartItem`.
  /// If no cart exists, returns an empty list.
  Future<List<CartItem>> loadCart() async {
    final jsonString = await getCartString();
    if (jsonString == null) return [];
    final List<dynamic> jsonList = json.decode(jsonString);
    return jsonList.map((item) => CartItem.fromJson(item)).toList();
  }

  /// Saves the cart to SharedPreferences by encoding the list of `CartItem` to JSON.
  Future<void> saveCart(List<CartItem> cart) async {
    final jsonList = cart.map((item) => item.toJson()).toList();
    await saveCartString(json.encode(jsonList));
  }

  // ================================================================
  // Theme preference
  // ================================================================

  /// Returns the stored theme mode as a string: 'light', 'dark', or null if not set.
  Future<String?> getThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(AppConstants.keyTheme);
  }

  /// Saves the theme preference ('light' or 'dark') to SharedPreferences.
  Future<void> saveThemeMode(String mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.keyTheme, mode);
  }
}