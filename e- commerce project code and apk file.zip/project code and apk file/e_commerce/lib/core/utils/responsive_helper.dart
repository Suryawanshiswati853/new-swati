import 'package:e_commerce/app/export.dart';



class ResponsiveHelper {
  static double getScreenWidth(BuildContext context) {
    return MediaQuery.of(context).size.width;
  }

  static double getScreenHeight(BuildContext context) {
    return MediaQuery.of(context).size.height;
  }

  // Base width: 375 (iPhone SE)
  static double scaleFactor(BuildContext context) {
    return getScreenWidth(context) / 375;
  }

  static double width(BuildContext context, double size) {
    return size * scaleFactor(context);
  }

  static double height(BuildContext context, double size) {
    return size * scaleFactor(context);
  }

  static double fontSize(BuildContext context, double size) {
    return size * scaleFactor(context);
  }

  static double padding(BuildContext context, double size) {
    return size * scaleFactor(context);
  }

  static double horizontalPadding(BuildContext context) => width(context, 16);
  static double verticalPadding(BuildContext context) => height(context, 12);
}

// Optional: Extension for easier use
extension ResponsiveExtension on BuildContext {
  double get screenWidth => ResponsiveHelper.getScreenWidth(this);
  double get screenHeight => ResponsiveHelper.getScreenHeight(this);
  double get scaleFactor => ResponsiveHelper.scaleFactor(this);
  double w(double size) => ResponsiveHelper.width(this, size);
  double h(double size) => ResponsiveHelper.height(this, size);
  double fs(double size) => ResponsiveHelper.fontSize(this, size);
  double pd(double size) => ResponsiveHelper.padding(this, size);
  double get horizontalPadding => ResponsiveHelper.horizontalPadding(this);
  double get verticalPadding => ResponsiveHelper.verticalPadding(this);
}