import 'package:e_commerce/app/export.dart';


class CartItem {
  final Product product;
  int quantity;

  CartItem({required this.product, this.quantity = 1});

  Map<String, dynamic> toJson() {
    return {
      'product': {
        'id': product.id,
        'title': product.title,
        'price': product.price,
        'image': product.image,
      },
      'quantity': quantity,
    };
  }

  factory CartItem.fromJson(Map<String, dynamic> json) {
    final productMap = json['product'];
    final product = Product(
      id: productMap['id'],
      title: productMap['title'],
      price: productMap['price'].toDouble(),
      description: '',
      category: '',
      image: productMap['image'],
      rating: Rating(rate: 0, count: 0),
    );
    return CartItem(
      product: product,
      quantity: json['quantity'],
    );
  }
}