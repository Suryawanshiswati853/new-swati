import 'package:e_commerce/app/export.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  late final LoginController controller;
  late final AnimationController _animationController;
  late final Animation<double> _fadeAnimation;
  late final Animation<double> _scaleAnimation;
  late final Animation<double> _textFadeAnimation;

  @override
  void initState() {
    super.initState();
    controller = Get.find<LoginController>();

    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );

    // Logo: fade + scale
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );
    _scaleAnimation = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutBack,
      ),
    );

    // Title: fade with delay
    _textFadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.4, 1.0, curve: Curves.easeOut),
    );

    // Start animation after the first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _animationController.forward();
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: context.pd(16)),
            child: Form(
              key: controller.formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // ---- Animated Logo ----
                  AnimatedBuilder(
                    animation: _animationController,
                    builder: (context, child) {
                      return Opacity(
                        opacity: _fadeAnimation.value,
                        child: Transform.scale(
                          scale: _scaleAnimation.value,
                          child: Image.asset(
                            ImageConstants.loginLogo,
                            height: context.h(200),
                            width: context.w(150),
                            fit: BoxFit.cover,
                          ),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: context.h(20)),
        
                  // ---- Animated Title ----
                  AnimatedBuilder(
                    animation: _animationController,
                    builder: (context, child) {
                      return Opacity(
                        opacity: _textFadeAnimation.value,
                        child: Text(
                          'Login to your account',
                          style: AppTextStyles.headline2(context),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: context.h(40)),
        
                  // ---- Username field ----
                  LoginTextField(
                     autovalidateMode: AutovalidateMode.onUserInteraction, 
                    controller: controller.usernameController,
                    label: 'Username',
                    icon: Icons.person,
                    isLoading: controller.isLoading.value,
                    keyboardType: TextInputType.text,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Username is required';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: context.h(16)),
        
                  // ---- Password field ----
                  LoginTextField(
                     autovalidateMode: AutovalidateMode.onUserInteraction, 
                    controller: controller.passwordController,
                    label: 'Password',
                    icon: Icons.lock,
                    obscureText: true,
                    isLoading: controller.isLoading.value,
                    keyboardType: TextInputType.visiblePassword,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Password is required';
                      }
                      if (value.length < 6) {
                        return 'Password must be at least 6 characters';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: context.h(24)),
        
                  // ---- Login button ----
                GetBuilder<LoginController>(
          builder: (ctrl) {
            return CommonButton(
        label: 'Login',
        onPressed: ctrl.login,
        isLoading: ctrl.isLoading.value,
        backgroundColor: context.isDarkMode ? AppColors.blue : AppColors.blue2,
        textColor: AppColors.backgroundLight,
        borderRadius: 8,
            );
          },
        ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}