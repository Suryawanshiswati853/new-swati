import 'package:e_commerce/app/export.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  late final CartController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.find<CartController>();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppBar(
 
  showBackButton: true, 
  
        title: 'Cart',
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline,color: AppColors.cardLight,),
            onPressed: controller.cartItems.isEmpty ? null : controller.clearCart,
          ),

        ],
      ),
      // get list of products contained cart
      body: GetBuilder<CartController>(
      
        builder: (ctrl) {
          if (controller.cartItems.isEmpty) {
            return EmptyStateWidget(
              icon: Icons.shopping_cart_outlined,
              message: 'Your cart is empty',
            );
          }
          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: EdgeInsets.all(context.pd(16)),
                  itemCount: controller.cartItems.length,
                  itemBuilder: (_, index) {
                    return CartItemWidget(
                      item: controller.cartItems[index],
                      index: index,
                    );
                  },
                ),
              ),
              const Divider(height: 1),
               //cart  summery contained  amount and items
              CartSummary(),
            ],
          );
        },
      ),
    );
  }
}