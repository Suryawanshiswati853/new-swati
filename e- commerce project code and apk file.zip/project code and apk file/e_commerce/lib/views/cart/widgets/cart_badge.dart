import 'package:e_commerce/app/export.dart';



class CartBadge extends StatelessWidget {
  const CartBadge({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CartController>(
      builder: (controller) {
        final count = controller.totalItems.value;
        return Stack(
          children: [
            IconButton(
              icon: const Icon(Icons.shopping_cart_outlined),
              onPressed: () => Get.toNamed(AppRoutes.cart),
            ),
            if (count > 0)
              Positioned(
                right: context.w(4),
                top: context.h(4),
                child: Container(
                  padding: EdgeInsets.all(context.pd(2)),
                  decoration: const BoxDecoration(
                    color: AppColors.error,
                    shape: BoxShape.circle,
                  ),
                  constraints: BoxConstraints(
                    minWidth: context.w(18),
                    minHeight: context.h(18),
                  ),
                  child: Text(
                    count.toString(),
                    style:AppTextStyles.bodyText1(context).copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}