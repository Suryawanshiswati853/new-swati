import 'package:e_commerce/app/export.dart';



class CartItemWidget extends StatelessWidget {
  final CartItem item;
  final int index;

  const CartItemWidget({super.key, required this.item, required this.index});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<CartController>();

    return Card(
      elevation: 2,
    color: AppTheme.isDarkMode(context)?AppColors.cardDark:AppColors.cardLight,

      margin: EdgeInsets.symmetric(vertical: context.h(4)),
      child: Padding(
        padding: EdgeInsets.all(context.pd(8)),
        child: Row(
          children: [
            // product image
            Image.network(
  item.product.image,
  width: context.w(70),
  height: context.w(70),
  fit: BoxFit.contain,
  loadingBuilder: (context, child, loadingProgress) {
    if (loadingProgress == null) return child; // loaded
    return Container(
    
      width: context.w(70),
      height: context.w(70),
      alignment: Alignment.center,
      child: CircularProgressIndicator(
        value: loadingProgress.expectedTotalBytes != null
            ? loadingProgress.cumulativeBytesLoaded /
                loadingProgress.expectedTotalBytes!
            : null,
      ),
    );
  },
  errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined),
),
            SizedBox(width: context.w(12)),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // product title
                  Text(
                    item.product.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.bodyText2(context),
                  ),
                  /// product price
                  Text(
                    '\$${item.product.price.toStringAsFixed(2)}',
                    style: AppTextStyles.bodyText1(context).copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: context.h(4)),
                  Row(
                    children: [
                      // increament quantity  and decrement quantity
                        QuantitySelector(
      value: item.quantity,
      onIncrement: () => controller.incrementQuantity(index),
      onDecrement: () => controller.decrementQuantity(index),
      buttonSize: 30,
      iconSize: 18,
    ),

                     
                      const Spacer(),
                      // delete icon
                      IconButton(
                        icon:  Icon(Icons.delete_outline, color:  AppTheme.isDarkMode(context)
              ? AppColors.backgroundLight
              : AppColors.backgroundDark,),
                        onPressed: () => controller.removeItem(index),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}