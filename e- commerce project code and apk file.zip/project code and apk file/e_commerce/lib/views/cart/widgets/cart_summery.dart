import 'package:e_commerce/app/export.dart';




class CartSummary extends StatelessWidget {
  const CartSummary({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<CartController>();

    return Container(
      padding: EdgeInsets.all(context.pd(16)),
      color: Theme.of(context).cardColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ---- Total items ----
          Text(
            'Total Items: ${controller.totalItems.value}',
            style: AppTextStyles.bodyText2(context),
          ),
          SizedBox(height: context.h(4)),
          // ---- Total amount ----
          Text(
            'Total Amount: \$${controller.totalAmount.value.toStringAsFixed(2)}',
            style: AppTextStyles.headline2(context).copyWith(
              color: AppColors.accent,
            ),
          ),
          SizedBox(height: context.h(16)), // spacing before button
          // ---- Checkout button ----
         CommonButton(
  label: 'Checkout',
  onPressed: () {
AppSnackbar.showInfo('Checkout', 'Proceed to payment', context: context);
  },
  backgroundColor:AppTheme.isDarkMode(context)? AppColors.blue:AppColors.blue2,
  //textColor: Colors.white,
  borderRadius: 8,
),
          SizedBox(height: context.h(8)),
        ],
      ),
    );
  }
}