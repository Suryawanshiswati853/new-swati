import 'package:e_commerce/app/export.dart';

class ProductDetailsScreen extends StatefulWidget {
  const ProductDetailsScreen({super.key});

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  // Only one controller declaration – Get.find will get the existing instance
  late final ProductController controller;
  late final int productId;

  @override
  void initState() {
    super.initState();

    // Read product ID from route parameters
    final idParam = Get.parameters['id'];
    if (idParam == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Get.back();
      });
      return;
    }
    productId = int.parse(idParam);
    controller = Get.find<ProductController>();

    // Fetch details after the frame is built to avoid build‑phase issues
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.fetchProductDetails(productId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppBar(
        showBackButton:true,
        title: 'Product Details',
        actions: [
         
        ],
      ),
      body: GetBuilder<ProductController>(
        builder: (ctrl) {
          // Loading
          if (ctrl.isLoadingDetails.value) {
            return _buildShimmerDetails(context);
          }
          // Error
          if (ctrl.isErrorDetails.value) {
            return _buildErrorState(context);
          }
          final product = ctrl.productDetails.value;
          if (product == null) {
            return const SizedBox.shrink();
          }
          // Product loaded
          return SingleChildScrollView(
            padding: EdgeInsets.all(context.pd(14)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
             
                // ProductImage(product: product),
                SizedBox(height: context.h(16)),
                productInfo(product: product),
                SizedBox(height: context.h(20)),

                Row(
      children: [
        QuantitySelector(
      value: controller.detailsQuantity.value,
      onIncrement: controller.incrementDetailsQuantity,
      onDecrement: controller.decrementDetailsQuantity,
      buttonSize: 40,
      iconSize: 20,
    ),
        SizedBox(width: context.w(20)),
        Expanded(
          child: CommonButton(
            height: context.h(40),
            width: context.w(80),

        label: 'Add to Cart',
        onPressed:(){
              final product = controller.productDetails.value;
              if (product != null) {
                controller.addToCartWithQuantity(
                  product,
                  controller.detailsQuantity.value,
                );
              }
            

        },
        backgroundColor: context.isDarkMode ? AppColors.blue : AppColors.blue2,
        textColor: AppColors.backgroundLight,
        borderRadius: 8,
            ),
          
        ),
      ],
                )
                
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildErrorState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline_outlined, size: 60, color: AppColors.error),
          SizedBox(height: context.h(16)),
          Text(
            'Failed to load product',
            style: AppTextStyles.headline2(context),
          ),
          SizedBox(height: context.h(20)),
          CommonButton(
            label: 'Retry',
            onPressed: () => controller.fetchProductDetails(productId),
            backgroundColor: context.isDarkMode ? AppColors.primaryDark : AppColors.primary,
            textColor: Colors.white,
            borderRadius: 8,
          ),
        ],
      ),
    );
  }

  Widget _buildShimmerDetails(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(context.pd(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ShimmerWidget.rectangular(
            context: context,
            height: context.h(250),
            width: double.infinity,
          ),
          SizedBox(height: context.h(16)),
          ShimmerWidget.rectangular(
            context: context,
            height: context.h(24),
            width: context.w(200),
          ),
          SizedBox(height: context.h(8)),
          ShimmerWidget.rectangular(
            context: context,
            height: context.h(60),
            width: double.infinity,
          ),
          SizedBox(height: context.h(12)),
          ShimmerWidget.rectangular(
            context: context,
            height: context.h(20),
            width: context.w(100),
          ),
          SizedBox(height: context.h(8)),
          ShimmerWidget.rectangular(
            context: context,
            height: context.h(20),
            width: context.w(150),
          ),
          SizedBox(height: context.h(8)),
          ShimmerWidget.rectangular(
            context: context,
            height: context.h(30),
            width: context.w(100),
          ),
          SizedBox(height: context.h(20)),
          Row(
            children: [
              ShimmerWidget.rectangular(
                context: context,
                height: context.h(40),
                width: context.w(40),
              ),
              SizedBox(width: context.w(10)),
              ShimmerWidget.rectangular(
                context: context,
                height: context.h(40),
                width: context.w(40),
              ),
              SizedBox(width: context.w(20)),
              Expanded(
                child: ShimmerWidget.rectangular(
                  context: context,
                  height: context.h(50),
                  width: double.infinity,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

