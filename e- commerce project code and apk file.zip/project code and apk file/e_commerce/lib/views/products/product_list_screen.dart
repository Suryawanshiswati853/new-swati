import 'package:e_commerce/app/export.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  final ProductController controller = Get.find<ProductController>();

  void _logout() {
    Get.find<StorageService>().logout();
    Get.offAllNamed(AppRoutes.login);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppBar(
        title: 'Products',
        actions: [
          // cart badge
          CartBadge(),
        
          IconButton(
            icon: const Icon(Icons.logout_outlined),
            onPressed: _logout,
            tooltip: 'Logout',
          ),
        ],
      ),
      body: Column(
        children: [
          // ---- Search Bar ----
          Padding(
            padding: EdgeInsets.symmetric(horizontal: context.pd(16), vertical: context.h(8)),
            child: TextField(
              onChanged: controller.filterProducts,
              decoration: InputDecoration(
                hintText: 'Search products...',
                prefixIcon:  Icon(Icons.search_outlined,color: AppTheme.isDarkMode(context)?AppColors.backgroundLight:AppColors.backgroundDark),
                border: OutlineInputBorder(
                
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: context.isDarkMode ? AppColors.cardDark : AppColors.backgroundLight,
                hintStyle: AppTextStyles.bodyText2(context).copyWith(
                  color: context.isDarkMode ? AppColors.white54 : AppColors.black54,
                ),
                 enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(
          color: context.isDarkMode ? AppColors.white54 : AppColors.grey,
          width: 1,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(
          color: context.isDarkMode ? AppColors.primaryDark : AppColors.blue2,
          width: 2,
        ),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.error, width: 1),
      ),
              ),
              style: AppTextStyles.bodyText2(context),
            ),
          ),
          // ---- Category Dropdown ----
          Padding(
            padding: EdgeInsets.symmetric(horizontal: context.pd(16)),
            child: GetBuilder<ProductController>(
              builder: (ctrl) {
                if (ctrl.categories.isEmpty) return const SizedBox.shrink();
                return DropdownButton<String>(
                  value: ctrl.selectedCategory.value.isEmpty ? null : ctrl.selectedCategory.value,
                  hint: Text(
                    'All Categories',
                    style: AppTextStyles.bodyText2(context).copyWith(
                      color: context.isDarkMode ? AppColors.white70 : AppColors.black54,
                    ),
                  ),
                  items: [
                    const DropdownMenuItem<String>(
                      value: null,
                      child: Text('All Categories'),
                    ),
                    ...ctrl.categories.map((category) {
                      return DropdownMenuItem<String>(
                        value: category,
                        child: Text(category),
                      );
                    }),
                  ],
                  onChanged: (value) {
                    ctrl.selectedCategory.value = value ?? '';
                    ctrl.applyFilters();
                  },
                  dropdownColor: context.isDarkMode ? AppColors.cardDark : AppColors.cardLight,
                  style: AppTextStyles.bodyText2(context).copyWith(
                    color: context.isDarkMode ? AppColors.backgroundLight : AppColors.backgroundDark,
                  ),
                  underline: Container(height: 0),
                  isExpanded: true,
                  icon: Icon(
                    Icons.arrow_drop_down,
                    size: 30,
                    color: context.isDarkMode ? AppColors.backgroundLight :AppColors.black87,
                  ),
                );
              },
            ),
          ),
          SizedBox(height: context.h(8)),
          // ---- Products Grid ----
          Expanded(
            child: GetBuilder<ProductController>(
              builder: (ctrl) {
                if (ctrl.isLoadingList.value) {
                  return _buildShimmerGrid(context);
                }
                if (ctrl.isErrorList.value) {
                  return _buildErrorState(context);
                }
                if (ctrl.displayedProducts.isEmpty) {
                  return EmptyStateWidget(
                    icon: Icons.search_off,
                    message: 'No products found',
                  );
                }
                return RefreshIndicator(
                  onRefresh: ctrl.refreshProducts,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: context.pd(16)),
                    child: GridView.builder(
                      padding: EdgeInsets.symmetric(vertical: context.h(12)),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: context.w(10),
                        mainAxisSpacing: context.h(10),
                        childAspectRatio: 0.7,
                      ),
                      itemCount: ctrl.displayedProducts.length,
                      itemBuilder: (_, index) {
                        return ProductCard(
                          product: ctrl.displayedProducts[index],
                        );
                      },
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline_outlined, size: 60, color: AppColors.error),
          SizedBox(height: context.h(16)),
          Text('Something went wrong', style: AppTextStyles.headline2(context)),
          SizedBox(height: context.h(8)),
          Text(
            controller.isConnected.value ? 'Please try again' : 'No internet connection',
            textAlign: TextAlign.center,
            style: AppTextStyles.bodyText2(context),
          ),
          SizedBox(height: context.h(20)),
          CommonButton(
            borderRadius: 8,
            elevation: 0,
            height: context.h(40),
            width: context.w(100),
            isLoading: controller.isRetrying.value,
            label: 'Retry',
            onPressed: controller.fetchProducts,
            backgroundColor: context.isDarkMode ? AppColors.primaryDark : AppColors.primary,
            textColor: Colors.white,
          ),
        ],
      ),
    );
  }

  Widget _buildShimmerGrid(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: context.pd(16)),
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: context.w(10),
          mainAxisSpacing: context.h(10),
          childAspectRatio: 0.7,
        ),
        itemCount: 6,
        itemBuilder: (_, __) => ShimmerWidget.rectangular(
          context: context,
          height: double.infinity,
          width: double.infinity,
        ),
      ),
    );
  }
}