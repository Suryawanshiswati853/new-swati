import 'package:e_commerce/app/export.dart';


class ProductCard extends StatelessWidget {
  final Product product;
  const ProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<ProductController>();

    return GestureDetector(
      onTap: () => controller.goToDetails(product.id),
      child: Card(
        color: AppTheme.isDarkMode(context)?AppColors.cardDark:AppColors.cardLight,
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- Image ---
            AspectRatio(
  aspectRatio: 2.0,
  child: ClipRRect(
    borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
    child: Image.network(
      product.image,
      fit: BoxFit.contain,
      width: double.infinity,
      loadingBuilder: (context, child, loadingProgress) {
        if (loadingProgress == null) {
          return child; // image fully loaded
        }
        // Show a circular progress indicator while loading
        return Center(
          child: CircularProgressIndicator(
            value: loadingProgress.expectedTotalBytes != null
                ? loadingProgress.cumulativeBytesLoaded /
                    loadingProgress.expectedTotalBytes!
                : null,
          ),
        );
      },
      errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined),
    ),
  ),
),
           
            // --- Details ---
            Padding(
              padding: EdgeInsets.all(context.pd(8)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.bodyText2(context),
                  ),
                  SizedBox(height: context.h(4)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // product price
                      Text(
                        '\$${product.price.toStringAsFixed(2)}',
                        style: AppTextStyles.bodyText1(context).copyWith(
                          fontWeight: FontWeight.bold,
                          color: AppColors.accent,
                        ),
                      ),
                      //product rating with icon star
                      Row(
                        children: [
                          Icon(Icons.star, size: context.fs(14), color: AppColors.amber),
                          Text(
                            ' ${product.rating.rate} (${product.rating.count})',
                            style: AppTextStyles.caption(context),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: context.h(4)),
                  // product category
                  Text(
                    product.category,
                    style: AppTextStyles.caption2(context),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: context.h(8)),
                  //-------button
                 CommonButton(
  label: 'Add to Cart',
  onPressed: () => controller.addToCart(product),
  height: context.h(36),
  backgroundColor: AppTheme.isDarkMode(context) ? AppColors.blue : AppColors.blue2,
  borderRadius: 8,
  elevation: 0,
)
                 
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

