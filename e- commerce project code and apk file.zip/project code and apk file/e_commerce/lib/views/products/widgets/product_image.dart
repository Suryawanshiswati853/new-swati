import 'package:e_commerce/app/export.dart';


class ProductImage extends StatelessWidget {
  final Product product;
  final double? height;
  final double? width;
  final double borderRadius;
  final BoxFit fit;
  final Color? backgroundColor;

  const ProductImage({
    super.key,
    required this.product,
    this.height,
    this.width,
    this.borderRadius = 16,
    this.fit = BoxFit.contain,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDarkMode(context);

    final effectiveHeight = height ?? context.h(270);
    final effectiveWidth = width ?? double.infinity;

    // ---- Theme-aware colours ----
    final bgColor = backgroundColor ??
        (isDark ? AppColors.cardDark : AppColors.cardLight);
    final shadowColor = isDark
        ? AppColors.backgroundLight.withOpacity(0.15)
        : AppColors.backgroundDark.withOpacity(0.15);
    final errorIconColor = isDark ? Colors.grey[600] : Colors.grey[400];

    // ---- Image widget ----
    final image = Image.network(
      product.image,
      height: effectiveHeight,
      width: effectiveWidth,
      fit: fit,
      errorBuilder: (_, __, ___) => Icon(
        Icons.broken_image_outlined,
        size: context.w(100), // responsive icon size
        color: errorIconColor,
      ),
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return Center(
          child: CircularProgressIndicator(
            value: progress.expectedTotalBytes != null
                ? progress.cumulativeBytesLoaded / progress.expectedTotalBytes!
                : null,
            color: isDark ? AppColors.primaryDark : AppColors.primary,
          ),
        );
      },
    );

    // ---- Responsive radius + shadow ----
    return Container(
      height: effectiveHeight,
      width: effectiveWidth,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(context.w(borderRadius)),
        boxShadow: [
          BoxShadow(
            color: shadowColor,
            blurRadius: context.w(8),   // responsive shadow blur
            offset: Offset(0, context.h(2)), // responsive offset
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(context.w(borderRadius)),
        child: image,
      ),
    );
  }
}