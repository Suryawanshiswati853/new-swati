import 'package:e_commerce/app/export.dart';


class productInfo extends StatelessWidget {
  final Product product;

  const productInfo({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDarkMode(context);

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: isDark ? AppColors.cardDark : AppColors.cardLight,
        borderRadius: BorderRadius.circular(context.w(16)),
        boxShadow: [
          BoxShadow(
            color: isDark
                ? Colors.white.withOpacity(0.08)
                : Colors.black.withOpacity(0.08),
            blurRadius: context.w(12),
            offset: Offset(0, context.h(4)),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
         
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // product image
              ProductImage(
                product: product,
                height: context.h(180),
                fit: BoxFit.contain,
                borderRadius: 16,
              ),
              //product title
              Padding(
                padding: EdgeInsets.fromLTRB(
                  context.pd(16),
                  context.h(12),
                  context.pd(16),
                  context.h(8),
                ),
                child: Text(
                  product.title,
                  style: AppTextStyles.headline2(context),
                ),
              ),
            ],
          ),

          // ---- Small gap between containers ----
          SizedBox(height: context.h(4)),

         
          Container(
            width: double.infinity,
            padding: EdgeInsets.only(left: context.pd(16),right: context.pd(16)),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: isDark
                      ? AppColors.backgroundLight.withOpacity(0.1)
                      : AppColors.backgroundDark.withOpacity(0.1),
                  width: 1,
                ),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // product price
                 Text(
                  '\$${product.price.toStringAsFixed(2)}',
                  style: AppTextStyles.headline1(context).copyWith(
                    color: AppColors.accent,
                  ),
                ),
             SizedBox(height: context.w(2)),

                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // product category
                    Text(
                      '${product.category}',
                      style: AppTextStyles.caption2(context),
                    ),
                    // ating with star icon
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, color: AppColors.amber, size: 20),
                        SizedBox(width: context.w(4)),
                        Text(
                          ' ${product.rating.rate} (${product.rating.count} reviews)',
                          style: AppTextStyles.caption(context),
                        ),
                      ],
                    ),
                  ],
                ),
                 SizedBox(height: context.w(10)),
                 // product description
                  Text(
                  "Product Description",
                  style: AppTextStyles.headline2(context),
                ),

                Text(
                  product.description,
                  style: AppTextStyles.bodyText1(context),
                ),
                SizedBox(height: context.h(12)),
               
               
              ],
            ),
          ),
        ],
      ),
    );
  }
}