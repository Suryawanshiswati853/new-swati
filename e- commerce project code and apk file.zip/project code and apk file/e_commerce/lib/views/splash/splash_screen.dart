import 'package:e_commerce/app/export.dart';


class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SplashController>(
      init: SplashController(),
      builder: (controller) {
        final theme = Theme.of(context);

        if (!controller.isConnected && !controller.isChecking) {
          return Scaffold(
            backgroundColor: theme.scaffoldBackgroundColor,
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.wifi_off_outlined,
                    size: context.w(80),
                    color: AppColors.error,
                  ),

                  SizedBox(height: context.h(16)),

                  Text(
                    'No Internet Connection',
                    style: theme.textTheme.headlineMedium,
                  ),

                  SizedBox(height: context.h(8)),

                  Text(
                    'Please check your network settings',
                    style: theme.textTheme.bodyMedium,
                  ),

                  SizedBox(height: context.h(24)),

                  CommonButton(
                    borderRadius: 8,
                    elevation: 0,
                    height: context.h(40),
                    width: context.w(100),
                    label: 'Retry',
                    onPressed: controller.retry,
                    backgroundColor: theme.primaryColor,
                  ),
                ],
              ),
            ),
          );
        }

        return Scaffold(
          backgroundColor: theme.scaffoldBackgroundColor,
          body: Center(
            child: TweenAnimationBuilder<double>(
              tween: Tween<double>(
                begin: 0.0,
                end: 1.0,
              ),
              duration: const Duration(
                milliseconds: 1500,
              ),
              curve: Curves.easeInOut,
              builder: (
                context,
                opacity,
                child,
              ) {
                return Opacity(
                  opacity: opacity,
                  child: child,
                );
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TweenAnimationBuilder<double>(
                    tween: Tween<double>(
                      begin: 0.6,
                      end: 1.0,
                    ),
                    duration: const Duration(
                      milliseconds: 1200,
                    ),
                    curve: Curves.easeOutBack,
                    builder: (
                      context,
                      scale,
                      child,
                    ) {
                      return Transform.scale(
                        scale: scale,
                        child: child,
                      );
                    },
                    child: Image.asset(
                      ImageConstants.appLogo,
                      width: context.w(200),
                      height: context.h(180),
                      fit: BoxFit.cover,
                    ),
                  ),

                  SizedBox(height: context.h(20)),

                  Text(
                    'E-Commerce',
                    style: AppTextStyles.headline1(context).copyWith(
                      color:AppTheme.isDarkMode(context)? AppColors.backgroundLight:AppColors.blue
                    ),
                   
                  ),

                  if (controller.isChecking)
                    Padding(
                      padding: EdgeInsets.only(
                        top: context.h(20),
                      ),
                      child: CircularProgressIndicator(
                        color: theme.primaryColor,
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

