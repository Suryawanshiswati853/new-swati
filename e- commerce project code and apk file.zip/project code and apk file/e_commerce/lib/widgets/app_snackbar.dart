import 'package:e_commerce/app/export.dart';




class AppSnackbar {
  static void showSuccess(
    String message, {
    BuildContext? context,
    Duration duration = const Duration(seconds: 3),
  }) {
    final isDark = context?.isDarkMode ?? Get.context?.isDarkMode ?? false;
    final backgroundColor = isDark
        ? AppColors.snackbarSuccessDark
        : AppColors.snackbarSuccessLight;
    final textColor = AppColors.snackbarTextLight;

    _showSnackbar('Success', message, backgroundColor, textColor, duration);
  }

  static void showError(
    String message, {
    BuildContext? context,
    Duration duration = const Duration(seconds: 4),
  }) {
    final isDark = context?.isDarkMode ?? Get.context?.isDarkMode ?? false;
    final backgroundColor = isDark
        ? AppColors.snackbarErrorDark
        : AppColors.snackbarErrorLight;
    final textColor = AppColors.snackbarTextLight;

    _showSnackbar('Error', message, backgroundColor, textColor, duration);
  }

  static void showInfo(
      String title,

    String message, {
    BuildContext? context,
    Duration duration = const Duration(seconds: 3),
  }) {
    final isDark = context?.isDarkMode ?? Get.context?.isDarkMode ?? false;
    final backgroundColor = isDark
        ? AppColors.blue
        : AppColors.blue2;
    final textColor = isDark?AppColors.backgroundLight:AppColors.backgroundLight;

    _showSnackbar(title, message, backgroundColor, textColor, duration);
  }

  static void showWarning(
    String message, {
    BuildContext? context,
    Duration duration = const Duration(seconds: 3),
  }) {
    final isDark = context?.isDarkMode ?? Get.context?.isDarkMode ?? false;
    final backgroundColor = isDark
        ? AppColors.snackbarWarningDark
        : AppColors.snackbarWarningLight;
    final textColor = isDark
        ? AppColors.snackbarTextDark
        : AppColors.snackbarTextLight; 

    _showSnackbar('Warning', message, backgroundColor, textColor, duration);
  }

  static void _showSnackbar(
    String title,
    String message,
    Color backgroundColor,
    Color textColor,
    Duration duration,
  ) {
    Get.snackbar(
      title,
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: backgroundColor,
      colorText: textColor,
      duration: duration,
      margin: const EdgeInsets.all(10),
      borderRadius: 8,
    );
  }
}