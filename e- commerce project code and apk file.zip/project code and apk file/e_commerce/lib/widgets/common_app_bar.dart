import 'package:e_commerce/app/export.dart';



class CommonAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final Widget? leading;
  final bool automaticallyImplyLeading;
  final bool showBackButton;
  final Color? backgroundColor;
  final double elevation;

  const CommonAppBar({
    super.key,
    required this.title,
    this.actions,
    this.leading,
    this.automaticallyImplyLeading = true,
    this.showBackButton = false,
    this.backgroundColor,
    this.elevation = 4,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDarkMode(context);
    final bgColor = backgroundColor ??
        (isDark ? AppColors.blue : AppColors.blue2);

    return AppBar(
      backgroundColor: bgColor,
      elevation: elevation,
      shadowColor: isDark ? AppColors.black54 : AppColors.black12,
      title: Text(
        title,
        style: AppTextStyles.headline2(context).copyWith(
          color: AppColors.cardLight,
        ),
      ),
      leading: leading ?? (showBackButton && Navigator.canPop(context)
          ? IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: AppColors.cardLight),
              onPressed: () => Get.back(),
            )
          : null),
      automaticallyImplyLeading: automaticallyImplyLeading && (leading == null),
      actions: actions,
      centerTitle: true,
      iconTheme: const IconThemeData(color: AppColors.cardLight),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}