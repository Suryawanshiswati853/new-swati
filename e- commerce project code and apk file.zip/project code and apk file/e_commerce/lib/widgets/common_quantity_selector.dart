import 'package:e_commerce/app/export.dart';



class QuantitySelector extends StatelessWidget {
  final int value;
  final VoidCallback onIncrement;
  final VoidCallback onDecrement;
  final double buttonSize;
  final double iconSize;

  const QuantitySelector({
    super.key,
    required this.value,
    required this.onIncrement,
    required this.onDecrement,
    this.buttonSize = 30,
    this.iconSize = 18,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDarkMode(context);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // - icon
        _buildButton(
          context,
          icon: Icons.remove,
          onPressed: onDecrement,
          isDark: isDark,
        ),
        SizedBox(width: 8),
        // value
        Text(
          value.toString(),
          style: AppTextStyles.headline2(context),
        ),
        SizedBox(width: 8),
        // + icon
        _buildButton(
          context,
          icon: Icons.add,
          onPressed: onIncrement,
          isDark: isDark,
        ),
      ],
    );
  }

  Widget _buildButton(BuildContext context,
      {required IconData icon,
      required VoidCallback onPressed,
      required bool isDark}) {
    return Container(
      width: buttonSize,
      height: buttonSize,
      decoration: BoxDecoration(
        color: isDark ? AppColors.blue : AppColors.blue2,
        shape: BoxShape.circle,
        border: Border.all(
          color: isDark ? AppColors.borderDark : AppColors.borderLight,
        ),
      ),
      child: IconButton(
        icon: Icon(icon, size: iconSize),
        color: AppColors.backgroundLight,
        onPressed: onPressed,
        constraints: const BoxConstraints(),
        padding: EdgeInsets.zero,
      ),
    );
  }
}