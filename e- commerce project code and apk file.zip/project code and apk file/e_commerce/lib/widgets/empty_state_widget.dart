import 'package:e_commerce/app/export.dart';


class EmptyStateWidget extends StatelessWidget {
  final IconData icon;
  final String message;

  const EmptyStateWidget({
    super.key,
    required this.icon,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: context.w(60), 
            color:AppTheme.isDarkMode(context)? AppColors.backgroundLight:AppColors.backgroundDark,
          ),
          SizedBox(height: context.h(16)),
          Text(
            message,
            style: AppTextStyles.headline2(context)
          ),
        ],
      ),
    );
  }
}