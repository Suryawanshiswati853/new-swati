import 'package:e_commerce/app/export.dart';


class ShimmerWidget {
  /// Theme‑aware rectangular shimmer using AppColors.
  static Widget rectangular({
    double height = double.infinity,
    double width = double.infinity,
    double radius = 8,
    BuildContext? context,
    Color? baseColor,
    Color? highlightColor,
  }) {
    final isDark = context != null
        ? Theme.of(context).brightness == Brightness.dark
        : false;

    final base = baseColor ??
        (isDark ? AppColors.shimmerBaseDark : AppColors.shimmerBaseLight);
    final highlight = highlightColor ??
        (isDark ? AppColors.shimmerHighlightDark : AppColors.shimmerHighlightLight);

    return Shimmer.fromColors(
      baseColor: base,
      highlightColor: highlight,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: isDark ? AppColors.cardDark : AppColors.cardLight,
          borderRadius: BorderRadius.circular(radius),
        ),
      ),
    );
  }

  /// Theme‑aware circular shimmer using AppColors.
  static Widget circular({
    double size = 50,
    BuildContext? context,
    Color? baseColor,
    Color? highlightColor,
  }) {
    final isDark = context != null
        ? Theme.of(context).brightness == Brightness.dark
        : false;

    final base = baseColor ??
        (isDark ? AppColors.shimmerBaseDark : AppColors.shimmerBaseLight);
    final highlight = highlightColor ??
        (isDark ? AppColors.shimmerHighlightDark : AppColors.shimmerHighlightLight);

    return Shimmer.fromColors(
      baseColor: base,
      highlightColor: highlight,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: isDark ? AppColors.cardDark : AppColors.cardLight,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}