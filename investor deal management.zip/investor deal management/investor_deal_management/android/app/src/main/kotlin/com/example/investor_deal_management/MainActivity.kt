package com.example.investor_deal_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
