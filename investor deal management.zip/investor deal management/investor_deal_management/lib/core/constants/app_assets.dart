class AppAssets {
  static const String logoLight = 'assets/logo/light_logo.png';
  static const String logoDark = 'assets/logo/dark_logo.png';
  static const String defaultAvatar = 'assets/logo/profile.png';
  static const String darkEmptyState = 'assets/images/not_found_dark.png';
  static const String lightEmptyState = 'assets/images/not_found_light.png';
}