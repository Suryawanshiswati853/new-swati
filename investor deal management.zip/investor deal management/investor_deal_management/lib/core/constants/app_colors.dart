import 'export.dart';

class AppColors {
  // Light theme
  static const Color primaryLight = Color(0xFF0A2540);
  static const Color accentLight = Color(0xFF00A86B);
  static const Color backgroundLight = Color(0xFFF8F9FA);
  static const Color cardLight = Colors.white;
  static const Color textLight = Color(0xFF1A2C3E);
  static const Color subtitleLight = Color(0xFF6C757D);
  static const Color orangeColor = Colors.orange;
  static const Color blueColor = Colors.blue;
  static const Color purpleColor = Colors.purple;
  static const Color tealColor = Colors.teal;
  static const Color redColor = Colors.red;

  // Dark theme
  static const Color primaryDark = Color(0xFF121212);
  static const Color accentDark = Color(0xFF00D47E);
  static const Color backgroundDark = Color(0xFF1E1E1E);
  static const Color cardDark = Color(0xFF2C2C2C);
  static const Color textDark = Color(0xFFE0E0E0);
  static const Color subtitleDark = Color(0xFF9E9E9E);

  // Risk colors
  static const Color riskLow = Color(0xFF28A745);
  static const Color riskMedium = Color(0xFFFFC107);
  static const Color riskHigh = Color(0xFFDC3545);

  // Status colors
  static const Color statusOpen = Color(0xFF28A745);
  static const Color grey = Colors.grey;
  static const Color greyShade400 = Color(0xFFBDBDBD);
  static const Color greyShade600 = Color(0xFF757575);
  static const Color greyShade800 = Color(0xFF424242);
  static const Color statusClosed = Color(0xFF6C757D);
}
