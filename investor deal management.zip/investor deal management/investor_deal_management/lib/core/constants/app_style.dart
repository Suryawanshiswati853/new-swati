import 'export.dart';

class AppTextStyles {
  static TextStyle headline1(BuildContext context) {
    return GoogleFonts.poppins(
      textStyle: Theme.of(context).textTheme.headlineMedium,
      fontSize: Responsive.fontSize(context, 5),
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle headline2(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GoogleFonts.poppins(
      color: isDark ? AppColors.backgroundLight : AppColors.primaryDark,
      textStyle: Theme.of(context).textTheme.titleLarge,
      fontSize: Responsive.fontSize(context, 4.5),
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle bodyText1(BuildContext context) {
    return GoogleFonts.inter(
      textStyle: Theme.of(context).textTheme.bodyLarge,
      fontSize: Responsive.fontSize(context, 3.5),
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle bodyText2(BuildContext context) {
    return GoogleFonts.inter(
      textStyle: Theme.of(context).textTheme.bodyMedium,
      fontSize: Responsive.fontSize(context, 4),
    );
  }

  static TextStyle caption(BuildContext context) {
    return GoogleFonts.inter(
      textStyle: Theme.of(context).textTheme.bodySmall,
      fontSize: Responsive.fontSize(context, 2.5),
      color: AppColors.grey,
    );
  }

  static TextStyle caption2(BuildContext context) {
    return GoogleFonts.inter(
      textStyle: Theme.of(context).textTheme.bodySmall,
      fontSize: Responsive.fontSize(context, 3.5),
    );
  }
}
