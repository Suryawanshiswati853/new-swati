export 'package:investor_deal_management/presentation/home/home_screen.dart';
export 'package:investor_deal_management/presentation/auth/login_screen.dart';
export 'package:investor_deal_management/core/theme/app_theme.dart';

export 'package:investor_deal_management/presentation/widgets/deal_chip.dart';
export 'package:investor_deal_management/presentation/deal_list/deal_list_screen.dart';
export 'package:investor_deal_management/presentation/interests/my_interests_screen.dart';
export 'package:investor_deal_management/core/widgets/custom_drawer.dart';

export 'package:investor_deal_management/core/widgets/roi_projection_chart.dart';
export 'package:investor_deal_management/core/widgets/animated_section_card.dart';
export 'package:investor_deal_management/logic/interests/interest_bloc.dart';
export 'package:investor_deal_management/logic/deals/deals_bloc.dart';
export 'package:investor_deal_management/core/widgets/empty_widget.dart';
export 'package:investor_deal_management/core/widgets/error_widget.dart';
export 'package:investor_deal_management/core/widgets/loading_widget.dart';
export 'package:investor_deal_management/core/widgets/search_filter_bar.dart';
export 'package:investor_deal_management/presentation/widgets/deal_card.dart';
export 'package:investor_deal_management/presentation/deal_details/deal_details_screen.dart';
export 'package:investor_deal_management/core/widgets/theme_aware_image.dart';
export 'package:investor_deal_management/core/constants/app_style.dart';
export 'package:investor_deal_management/core/constants/app_assets.dart';
export 'package:investor_deal_management/core/widgets/custom_button.dart';
export 'package:investor_deal_management/presentation/widgets/animated_text.dart';
export 'package:investor_deal_management/core/widgets/custom_textfield.dart';
export 'package:investor_deal_management/core/widgets/app_snack_bar.dart';
export 'package:investor_deal_management/core/constants/app_colors.dart';
export 'package:investor_deal_management/core/utils/validators.dart';

export 'package:investor_deal_management/data/repositories/interest_repository.dart';
export 'package:investor_deal_management/core/utils/filter_utils.dart';
export 'package:investor_deal_management/data/repositories/deal_repository.dart';
export 'package:investor_deal_management/data/models/deal_model.dart';
export 'package:equatable/equatable.dart';
export 'package:investor_deal_management/data/repositories/auth_repository.dart';
export 'package:flutter_bloc/flutter_bloc.dart';
export 'package:investor_deal_management/data/mock/mock_deals.dart';
export 'package:flutter/services.dart';
export 'dart:convert';

export 'package:investor_deal_management/data/local/shared_preferences_helper.dart';
export 'package:investor_deal_management/data/models/user_model.dart';
export 'package:shared_preferences/shared_preferences.dart';
export 'package:google_fonts/google_fonts.dart';
export '../utils/reponsive.dart';
export 'package:shimmer/shimmer.dart';
export 'package:flutter/material.dart';

export 'package:fl_chart/fl_chart.dart';

export 'package:investor_deal_management/logic/auth/auth_bloc.dart';
