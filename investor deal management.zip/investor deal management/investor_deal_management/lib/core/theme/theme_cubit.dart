import '../constants/export.dart';

class ThemeCubit extends Cubit<ThemeMode> {
  final SharedPreferencesHelper prefsHelper;

  ThemeCubit(this.prefsHelper) : super(ThemeMode.system);

  Future<void> loadTheme() async {
    final hasPreference = await prefsHelper.hasThemePreference();
    if (hasPreference) {
      final isDark = await prefsHelper.isDarkMode();
      emit(isDark ? ThemeMode.dark : ThemeMode.light);
    } else {
      emit(ThemeMode.system);
    }
  }

  Future<void> toggleTheme() async {
    final newMode = state == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    await prefsHelper.setDarkMode(newMode == ThemeMode.dark);
    emit(newMode);
  }
}
