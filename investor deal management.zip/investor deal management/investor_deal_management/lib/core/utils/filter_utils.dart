import '../constants/export.dart';

class FilterUtils {
  static List<Deal> applyFilters({
    required List<Deal> deals,
    required String searchQuery,
    double? minROI,
    double? maxROI,
    String? riskLevel,
    String? industry,
  }) {
    return deals.where((deal) {
      // Search by company name
      final query = searchQuery.toLowerCase();
      final matchesCompany = deal.companyName.toLowerCase().contains(query);
      final matchesROI = deal.expectedROI.toString().contains(query);
      final matchesIndustry = deal.industry.toLowerCase().contains(query);
      final matchesRisk = deal.riskLevel.toLowerCase().contains(query);
      final matchesStatus = deal.status.toLowerCase().contains(query);
      final matchesInvestment = deal.investmentRequired.toString().contains(
        query,
      );

      if (!(matchesCompany ||
          matchesROI ||
          matchesIndustry ||
          matchesRisk ||
          matchesStatus ||
          matchesInvestment)) {
        return false;
      }

      // ROI range filter
      if (minROI != null && deal.expectedROI < minROI) {
        return false;
      }
      if (maxROI != null && deal.expectedROI > maxROI) {
        return false;
      }

      // Risk level filter
      if (riskLevel != null && deal.riskLevel != riskLevel) {
        return false;
      }

      // Industry filter
      if (industry != null && deal.industry != industry) {
        return false;
      }

      return true;
    }).toList();
  }
}
