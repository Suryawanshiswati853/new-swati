import 'package:flutter/material.dart';

class Responsive {
  static double width(BuildContext context, double percentage) {
    return MediaQuery.of(context).size.width * (percentage / 100);
  }

  static double height(BuildContext context, double percentage) {
    return MediaQuery.of(context).size.height * (percentage / 100);
  }

  static double fontSize(BuildContext context, double percentage) {
    return MediaQuery.of(context).size.width * (percentage / 100);
  }

  static EdgeInsets symmetric({
    required BuildContext context,
    double horizontalPercent = 0,
    double verticalPercent = 0,
  }) {
    return EdgeInsets.symmetric(
      horizontal: width(context, horizontalPercent),
      vertical: height(context, verticalPercent),
    );
  }

  static EdgeInsets all(BuildContext context, double percent) {
    final val = width(context, percent);
    return EdgeInsets.all(val);
  }
}
