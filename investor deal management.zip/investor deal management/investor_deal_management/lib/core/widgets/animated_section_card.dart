import '../constants/export.dart';

class AnimatedSectionCard extends StatefulWidget {
  final String title;
  final Widget content;
  final Duration delay;
  final Duration duration;
  final double beginOffsetX;
  final double beginOffsetY;
  final EdgeInsets? padding;
  final IconData? icon;
  final bool showAccentBar;

  const AnimatedSectionCard({
    Key? key,
    required this.title,
    required this.content,
    this.delay = Duration.zero,
    this.duration = const Duration(milliseconds: 500),
    this.beginOffsetX = 0,
    this.beginOffsetY = 0.2,
    this.padding,
    this.icon,
    this.showAccentBar = true,
  }) : super(key: key);

  @override
  State<AnimatedSectionCard> createState() => _AnimatedSectionCardState();
}

class _AnimatedSectionCardState extends State<AnimatedSectionCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);
    _fade = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _slide = Tween<Offset>(
      begin: Offset(widget.beginOffsetX, widget.beginOffsetY),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    if (widget.delay == Duration.zero) {
      _controller.forward();
    } else {
      Future.delayed(widget.delay, () {
        if (mounted) _controller.forward();
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accentColor = isDark ? AppColors.accentDark : AppColors.accentLight;
    final titleColor = isDark
        ? AppColors.backgroundLight
        : AppColors.primaryLight;

    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: Card(
          elevation: isDark
              ? 8
              : 4, // higher elevation in dark mode for more shadow
          shadowColor: isDark
              ? AppColors.cardLight.withOpacity(0.2)
              : AppColors.cardDark.withOpacity(0.4),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: isDark
                ? BorderSide(color: AppColors.greyShade800, width: 0.5)
                : BorderSide.none,
          ),
          child: Padding(
            padding:
                widget.padding ?? EdgeInsets.all(Responsive.width(context, 4)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (widget.showAccentBar) ...[
                      Container(
                        width: 4,
                        height: Responsive.fontSize(context, 4.5),
                        decoration: BoxDecoration(
                          color: accentColor,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      SizedBox(width: Responsive.width(context, 2)),
                    ],
                    if (widget.icon != null) ...[
                      Icon(
                        widget.icon,
                        size: Responsive.fontSize(context, 8),
                        color: accentColor,
                      ),
                      SizedBox(width: Responsive.width(context, 2)),
                    ],
                    Expanded(
                      child: Text(
                        widget.title,
                        style: AppTextStyles.headline2(
                          context,
                        ).copyWith(color: titleColor),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: Responsive.height(context, 1.5)),
                widget.content,
              ],
            ),
          ),
        ),
      ),
    );
  }
}
