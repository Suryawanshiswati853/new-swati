import '../constants/export.dart';

class AppSnackBar {
  static void show({
    required BuildContext context,
    required String message,
    Color? backgroundColor,
    Duration duration = const Duration(seconds: 3),
    SnackBarAction? action,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor =
        backgroundColor ??
        (isDark ? AppColors.greyShade800 : AppColors.greyShade400);
    final textColor = isDark
        ? AppColors.backgroundLight
        : AppColors.backgroundDark;

    final snackBar = SnackBar(
      content: Text(
        message,
        style: AppTextStyles.bodyText1(context).copyWith(color: textColor),
      ),
      backgroundColor: bgColor,
      duration: duration,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      action: action,
    );

    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  // Success snackbar 
  static void showSuccess({
    required BuildContext context,
    required String message,
  }) {
    show(
      context: context,
      message: message,
      backgroundColor: Colors.green[800],
    );
  }

  // Error snackbar 
  static void showError({
    required BuildContext context,
    required String message,
  }) {
    show(context: context, message: message, backgroundColor: AppColors.riskHigh);
  }
}
