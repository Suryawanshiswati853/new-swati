import '../constants/export.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isLoading;
  final bool isOutlined;
  final IconData? icon;
  final Color? textColor;
  final Color? backgroundColor; // optional override

  const CustomButton({
    Key? key,
    required this.text,
    this.onPressed,
    this.isLoading = false,
    this.isOutlined = false,
    this.icon,
    this.textColor,
    this.backgroundColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Theme-aware defaults
    final defaultBgColor = isDark
        ? AppColors.accentLight
        : AppColors.primaryLight;
    final defaultTextColor = isDark
        ? AppColors.cardLight
        : AppColors.accentDark; // both white
    final effectiveBgColor = backgroundColor ?? defaultBgColor;
    final effectiveTextColor = textColor ?? defaultTextColor;

    final textStyle = AppTextStyles.bodyText1(
      context,
    ).copyWith(color: effectiveTextColor);

    Widget button;
    if (isOutlined) {
      button = OutlinedButton.icon(
        onPressed: isLoading ? null : onPressed,
        icon: icon != null
            ? Icon(icon, size: Responsive.fontSize(context, 4.5))
            : const SizedBox.shrink(),
        label: isLoading
            ? SizedBox(
                height: Responsive.height(context, 2.5),
                width: Responsive.width(context, 5),
                child: const CircularProgressIndicator(strokeWidth: 2),
              )
            : Text(text, style: textStyle),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: effectiveBgColor, width: 1.5),
          foregroundColor: effectiveTextColor,
          minimumSize: Size(double.infinity, Responsive.height(context, 6)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Responsive.width(context, 2)),
          ),
        ),
      );
    } else {
      button = ElevatedButton.icon(
        onPressed: isLoading ? null : onPressed,
        icon: icon != null
            ? Icon(icon, size: Responsive.fontSize(context, 4.5))
            : const SizedBox.shrink(),
        label: isLoading
            ? SizedBox(
                height: Responsive.height(context, 2.5),
                width: Responsive.width(context, 5),
                child: const CircularProgressIndicator(strokeWidth: 2),
              )
            : Text(text, style: textStyle),
        style: ElevatedButton.styleFrom(
          backgroundColor: effectiveBgColor,
          foregroundColor: effectiveTextColor,
          minimumSize: Size(double.infinity, Responsive.height(context, 6)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Responsive.width(context, 2)),
          ),
        ),
      );
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeInOut,
      child: button,
    );
  }
}
