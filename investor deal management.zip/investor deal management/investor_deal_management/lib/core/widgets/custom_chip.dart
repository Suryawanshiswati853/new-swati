import '../constants/export.dart';

class FilterChipGroup extends StatelessWidget {
  final List<String> options;
  final Set<String> selectedOptions;
  final Function(String) onSelected;

  const FilterChipGroup({
    Key? key,
    required this.options,
    required this.selectedOptions,
    required this.onSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: Responsive.width(context, 2), 
      runSpacing: Responsive.height(context, 1),
      children: options.map((option) {
        return FilterChip(
          label: Text(option),
          selected: selectedOptions.contains(option),
          onSelected: (selected) => onSelected(option),
          backgroundColor: Theme.of(context).brightness == Brightness.light
              ? Colors.grey[200]
              : Colors.grey[800],
          selectedColor: AppColors.accentLight.withOpacity(0.3),
          checkmarkColor: AppColors.accentLight,
        );
      }).toList(),
    );
  }
}
