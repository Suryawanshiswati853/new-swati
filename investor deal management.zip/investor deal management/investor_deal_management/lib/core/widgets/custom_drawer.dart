import '../constants/export.dart';

class CustomDrawer extends StatelessWidget {
  final User? user;
  final int selectedIndex;
  final Function(int) onItemSelected;

  const CustomDrawer({
    Key? key,
    required this.user,
    required this.selectedIndex,
    required this.onItemSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final headerColor = isDark
        ? AppColors.backgroundDark
        : Theme.of(context).primaryColor;

    return Drawer(
      child: Column(
        children: [
          _buildDrawerHeader(context, headerColor),
          SizedBox(height: Responsive.height(context, 2)),
          // Navigation Items
          _buildDrawerItem(
            context,
            icon: Icons.trending_up_outlined,
            title: 'Deals',
            isSelected: selectedIndex == 0,
            onTap: () {
              onItemSelected(0);
            },
          ),
          Divider(
            thickness: 1.0,
            color: Theme.of(context).brightness == Brightness.dark
                ? AppColors.greyShade800
                : AppColors.greyShade400,
            height: 5,
          ),

          _buildDrawerItem(
            context,
            icon: Icons.favorite_outlined,
            title: 'My Interests',
            isSelected: selectedIndex == 1,
            onTap: () {
              onItemSelected(1);
            },
          ),
          Divider(
            thickness: 1.0,
            color: Theme.of(context).brightness == Brightness.dark
                ? AppColors.greyShade800
                : AppColors.greyShade400,
            height: 5,
          ),
          // Logout
          _buildDrawerItem(
            context,
            icon: Icons.logout_outlined,
            title: 'Logout',
            onTap: () {
              Navigator.pop(context);
              context.read<AuthBloc>().add(LogoutRequested());
            },
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerHeader(BuildContext context, Color headerColor) {
    final statusBarHeight = MediaQuery.of(context).padding.top;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(
        Responsive.width(context, 5), // left
        Responsive.width(context, 8) +
            statusBarHeight, // top (extra for status bar)
        Responsive.width(context, 5), // right
        Responsive.height(context, 3), // bottom
      ),
      decoration: BoxDecoration(
        color: headerColor,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).brightness == Brightness.dark
                ? AppColors.backgroundLight.withOpacity(0.3)
                : AppColors.primaryDark.withOpacity(0.3),
            blurRadius: Responsive.width(context, 2),
            offset: Offset(0, Responsive.height(context, 0.6)),
          ),
        ],
      ),
      child: Column(
        children: [
          CircleAvatar(
            radius: Responsive.width(context, 12),
            backgroundColor: AppColors.backgroundLight,
            child: ClipOval(
              child: Image.asset(
                AppAssets.defaultAvatar,
                width: Responsive.width(context, 24),
                height: Responsive.width(context, 24),
                fit: BoxFit.contain,
                alignment: Alignment.center,
              ),
            ),
          ),
          SizedBox(height: Responsive.height(context, 2)),
          Text(
            user?.name ?? 'Investor',
            style: AppTextStyles.headline1(
              context,
            ).copyWith(color: AppColors.backgroundLight),
          ),
          SizedBox(height: Responsive.height(context, 1)),
          Text(
            user?.email ?? 'investor@example.com',
            style: AppTextStyles.bodyText1(
              context,
            ).copyWith(color: AppColors.greyShade400),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    bool isSelected = false,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final selectedColor = isDark
        ? AppColors.accentLight
        : Theme.of(context).primaryColor;

    return ListTile(
      leading: Icon(
        icon,
        color: isSelected
            ? selectedColor
            : (isDark ? AppColors.backgroundLight : AppColors.backgroundDark),
      ),
      title: Text(
        title,
        style: TextStyle(
          color: isSelected
              ? selectedColor
              : (isDark ? AppColors.backgroundLight : AppColors.backgroundDark),
          fontWeight: isSelected ? FontWeight.bold : null,
        ),
      ),
      selected: isSelected,
      onTap: onTap,
      contentPadding: EdgeInsets.symmetric(
        horizontal: Responsive.width(context, 5),
        vertical: 0,
      ),
    );
  }
}
