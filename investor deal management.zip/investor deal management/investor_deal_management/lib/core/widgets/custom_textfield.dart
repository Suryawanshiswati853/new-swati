import '../constants/export.dart';

class CustomTextFormField extends StatefulWidget {
  final TextEditingController? controller;
  final String labelText;
  final IconData prefixIcon;
  final bool obscureText;
  final String? Function(String?)? validator;
  final TextInputType keyboardType;
  final String? initialValue;
  final VoidCallback? onTap;
  final bool readOnly;
  final int maxLines;
  final AutovalidateMode? autovalidateMode;
  final bool isPassword;

  const CustomTextFormField({
    Key? key,
    this.controller,
    required this.labelText,
    required this.prefixIcon,
    this.obscureText = false,
    this.validator,
    this.keyboardType = TextInputType.text,
    this.initialValue,
    this.onTap,
    this.readOnly = false,
    this.maxLines = 1,
    this.autovalidateMode,
    this.isPassword = false,
  }) : super(key: key);

  @override
  State<CustomTextFormField> createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  late bool _obscureText;

  @override
  void initState() {
    super.initState();
    _obscureText = widget.obscureText;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final borderColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
    final focusColor = AppColors.accentLight;

    return TextFormField(
      autovalidateMode: widget.autovalidateMode,
      controller: widget.controller,
      initialValue: widget.initialValue,
      obscureText: _obscureText,
      validator: widget.validator,
      keyboardType: widget.keyboardType,
      readOnly: widget.readOnly,
      onTap: widget.onTap,
      maxLines: widget.maxLines,
      decoration: InputDecoration(
        labelText: widget.labelText,
        prefixIcon: Icon(widget.prefixIcon),
        suffixIcon: widget.isPassword
            ? IconButton(
                icon: Icon(
                  _obscureText ? Icons.visibility_off : Icons.visibility,
                  color: isDark
                      ? AppColors.backgroundLight
                      : AppColors.backgroundDark,
                ),
                onPressed: () {
                  setState(() {
                    _obscureText = !_obscureText;
                  });
                },
              )
            : null,
        labelStyle: AppTextStyles.bodyText1(context).copyWith(
          fontSize: Responsive.fontSize(context, 3.5),
          color: isDark ? AppColors.greyShade400 : AppColors.greyShade600,
        ),
        hintStyle: AppTextStyles.bodyText2(
          context,
        ).copyWith(fontSize: Responsive.fontSize(context, 3)),
        errorStyle: AppTextStyles.caption(context).copyWith(
          fontSize: Responsive.fontSize(context, 2.8),
          color: AppColors.riskHigh,
        ),
        contentPadding: EdgeInsets.symmetric(
          horizontal: Responsive.width(context, 4),
          vertical: Responsive.height(context, 1.5),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(Responsive.width(context, 2)),
          borderSide: BorderSide(color: borderColor, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(Responsive.width(context, 2)),
          borderSide: BorderSide(color: borderColor),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(Responsive.width(context, 2)),
          borderSide: BorderSide(color: focusColor, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(Responsive.width(context, 2)),
          borderSide: BorderSide(color: AppColors.riskHigh, width: 1),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(Responsive.width(context, 2)),
          borderSide: const BorderSide(color: AppColors.riskHigh, width: 2),
        ),
      ),
      style: AppTextStyles.bodyText1(context).copyWith(
        fontSize: Responsive.fontSize(context, 3.5),
        color: isDark ? AppColors.backgroundLight : AppColors.backgroundDark,
      ),
    );
  }
}
