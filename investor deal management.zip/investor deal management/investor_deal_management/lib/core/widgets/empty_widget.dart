import '../constants/export.dart';

class EmptyStateWidget extends StatelessWidget {
  final String title;
  final String subtitle;

  const EmptyStateWidget({
    Key? key,
    required this.title,
    required this.subtitle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final subtitleColor = isDark
        ? AppColors.greyShade400
        : AppColors.greyShade600;

    return LayoutBuilder(
      builder: (context, constraints) {
        final shouldScroll =
            constraints.maxHeight < 400; 
        final content = Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ThemeAwareImage(
              lightAsset: AppAssets.lightEmptyState,
              darkAsset: AppAssets.darkEmptyState,
              width: Responsive.width(context, 60),
              height: Responsive.width(context, 60),
              duration: const Duration(milliseconds: 700),
            ),
            Text(
              title,
              style: AppTextStyles.headline2(context).copyWith(
                fontSize: Responsive.fontSize(context, 5), // reduced from 7
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: Responsive.height(context, 1)),
            Text(
              subtitle,
              style: AppTextStyles.bodyText2(
                context,
              ).copyWith(color: subtitleColor),
              textAlign: TextAlign.center,
            ),
          ],
        );

        if (shouldScroll) {
          return SingleChildScrollView(
            child: SizedBox(height: constraints.maxHeight, child: content),
          );
        } else {
          return Center(child: content);
        }
      },
    );
  }
}
