import '../constants/export.dart';

class ErrorDisplayWidget extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const ErrorDisplayWidget({
    Key? key,
    required this.message,
    required this.onRetry,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline,
            size: Responsive.width(context, 10),
            color: Colors.red,
          ),
          SizedBox(height: Responsive.height(context, 2)),
          Text(
            message,
            style: TextStyle(fontSize: Responsive.fontSize(context, 3.5)),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: Responsive.height(context, 3)),
          CustomButton(text: 'Retry', onPressed: onRetry, isOutlined: true),
        ],
      ),
    );
  }
}
