import '../constants/export.dart';

class CustomLoadingWidget extends StatefulWidget {
  final String? message;
  final double iconSize;
  final Duration duration;

  const CustomLoadingWidget({
    Key? key,
    this.message = 'Loading deals...',
    this.iconSize = 60,
    this.duration = const Duration(milliseconds: 1200),
  }) : super(key: key);

  @override
  State<CustomLoadingWidget> createState() => _CustomLoadingWidgetState();
}

class _CustomLoadingWidgetState extends State<CustomLoadingWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _rotation;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this)
      ..repeat(); // infinite loop

    _rotation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.linear));

    _scale = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.2), weight: 1),
      TweenSequenceItem(tween: Tween(begin: 1.2, end: 1.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final iconColor = isDark
        ? AppColors.accentLight
        : Theme.of(context).primaryColor;
    final subtitleColor = isDark
        ? AppColors.greyShade400
        : AppColors.greyShade600;

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          RotationTransition(
            turns: _rotation,
            child: ScaleTransition(
              scale: _scale,
              child: Icon(
                Icons.trending_up_outlined,
                size: Responsive.width(
                  context,
                  widget.iconSize / 100,
                ), // responsive
                color: iconColor,
              ),
            ),
          ),
          SizedBox(height: Responsive.height(context, 2)),
          Text(
            widget.message!,
            style: AppTextStyles.bodyText2(
              context,
            ).copyWith(color: subtitleColor),
          ),
        ],
      ),
    );
  }
}
