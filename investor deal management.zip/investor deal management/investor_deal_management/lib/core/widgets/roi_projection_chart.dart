import '../constants/export.dart';



class RoiProjectionGraph extends StatefulWidget {
  final List<double> projections;
  final Color? chartColor;
  final double? graphHeight;
  final String? subtitle;

  const RoiProjectionGraph({
    Key? key,
    required this.projections,
    this.chartColor,
    this.graphHeight,
    this.subtitle,
  }) : super(key: key);

  @override
  State<RoiProjectionGraph> createState() => _RoiProjectionGraphState();
}

class _RoiProjectionGraphState extends State<RoiProjectionGraph>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final effectiveGraphHeight = widget.graphHeight ??
        (MediaQuery.of(context).size.height > 800 ? 180.0 : Responsive.height(context, 20));
    final effectiveSubtitle = widget.subtitle ?? 'Projected annual ROI distribution';

    if (widget.projections.isEmpty) {
      return Container(
        height: effectiveGraphHeight,
        alignment: Alignment.center,
        child: Text(
          'No projection data available',
          style: AppTextStyles.bodyText1(context).copyWith(color: Colors.grey),
        ),
      );
    }

    final total = widget.projections.fold(0.0, (sum, val) => sum + val);
    final avgROI = total / widget.projections.length;
    final radius = _getResponsiveRadius(context);
    final centerSpaceRadius = _getResponsiveCenterSpaceRadius(context);

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final t = _controller.value;  // t goes from 0 → 1 over 1.2 seconds
        final sections = _buildSections(context, radius, t);

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: effectiveGraphHeight,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  PieChart(
                    PieChartData(
                      sections: sections,
                      sectionsSpace: 2,
                      centerSpaceRadius: centerSpaceRadius,
                      startDegreeOffset: -90,
                      pieTouchData: PieTouchData(enabled: false),
                    ),
                    swapAnimationDuration: Duration.zero,
                  ),
                  FadeTransition(
                    opacity: _controller,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Yearly ROI',
                          style: AppTextStyles.caption(context).copyWith(
                            
                           
                            fontSize: Responsive.fontSize(context, 2.8),
                            fontWeight:FontWeight.w600,
                            color: isDark ? AppColors.greyShade400 : AppColors.greyShade600,
                          ),
                        ),
                        Text(
                          '${avgROI.toStringAsFixed(1)}%',
                          style: AppTextStyles.headline2(context).copyWith(
                            color: AppColors.accentLight,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: Responsive.height(context, 1.5)),
            Center(
              child: Text(
                effectiveSubtitle,
                style: AppTextStyles.caption2(context).copyWith(color:isDark ? AppColors.greyShade400 : AppColors.greyShade600,),
                textAlign: TextAlign.center,
                
              ),
            ),
          ],
        );
      },
    );
  }

  double _getResponsiveRadius(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return width > 800 ? 160.0 : width * 0.16;
  }

  double _getResponsiveCenterSpaceRadius(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return width > 800 ? 60.0 : width * 0.09;
  }

  List<PieChartSectionData> _buildSections(BuildContext context, double radius, double t) {
    final projections = widget.projections;
    final total = projections.fold(0.0, (sum, val) => sum + val);
    if (total == 0) return [];

    final colorPalette = [
      widget.chartColor ?? AppColors.accentLight,
      AppColors.orangeColor,
      AppColors.blueColor,
      AppColors.purpleColor,
      AppColors.tealColor,
      AppColors.redColor,
    ];
    final titleFontSize = Responsive.fontSize(context, 2.5).clamp(8.0, 14.0);

    List<PieChartSectionData> sections = [];
    for (int i = 0; i < projections.length; i++) {
      final roi = projections[i];
      final percentage = (roi / total) * 100;
      final animatedValue = percentage * t;

      sections.add(
        PieChartSectionData(
          value: animatedValue,
          title: animatedValue > 5 ? 'Y${i + 1}\n${roi.toStringAsFixed(1)}%' : '',
          radius: radius,
          titleStyle: AppTextStyles.caption(context).copyWith(
            fontSize: titleFontSize,
            fontWeight: FontWeight.bold,
            color: AppColors.backgroundLight,
          ),
          color: colorPalette[i % colorPalette.length],
          showTitle: animatedValue > 5,
        ),
      );
    }
    return sections;
  }
}
