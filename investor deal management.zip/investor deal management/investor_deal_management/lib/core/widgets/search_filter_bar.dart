import '../constants/export.dart';

class SearchAndFilterBar extends StatefulWidget {
  final TextEditingController searchController;
  final String searchQuery;
  final VoidCallback onSearchChanged;
  final VoidCallback onFilterPressed;
  final double? minROI;
  final double? maxROI;
  final String? riskLevel;
  final String? industry;
  final VoidCallback onClearFilters;

  const SearchAndFilterBar({
    Key? key,
    required this.searchController,
    required this.searchQuery,
    required this.onSearchChanged,
    required this.onFilterPressed,
    this.minROI,
    this.maxROI,
    this.riskLevel,
    this.industry,
    required this.onClearFilters,
  }) : super(key: key);

  @override
  State<SearchAndFilterBar> createState() => _SearchAndFilterBarState();
}

class _SearchAndFilterBarState extends State<SearchAndFilterBar>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _fade = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _slide = Tween<Offset>(
      begin: const Offset(0, -0.1), // slide from slightly above
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final showFilters =
        widget.minROI != null ||
        widget.maxROI != null ||
        widget.riskLevel != null ||
        widget.industry != null;

    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: Column(
          children: [
            // Search row
            Padding(
              padding: EdgeInsets.only(
                left: Responsive.width(context, 6),
                right: Responsive.width(context, 4),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: widget.searchController,
                      decoration: InputDecoration(
                        hintText: 'Search by company name...',
                        hintStyle: AppTextStyles.bodyText2(context).copyWith(
                          color: isDark
                              ? AppColors.greyShade400
                              : AppColors.greyShade600,
                        ),
                        prefixIcon: const Icon(Icons.search_outlined),
                        suffixIcon: widget.searchQuery.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear_outlined),
                                onPressed: () {
                                  widget.searchController.clear();
                                  widget.onSearchChanged();
                                },
                              )
                            : null,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(
                            Responsive.width(context, 2),
                          ),
                          borderSide: BorderSide(
                            color: isDark
                                ? AppColors.greyShade800
                                : AppColors.greyShade400,
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(
                            Responsive.width(context, 2),
                          ),
                          borderSide: BorderSide(
                            color: isDark
                                ? AppColors.greyShade800
                                : AppColors.greyShade400,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(
                            Responsive.width(context, 2),
                          ),
                          borderSide: const BorderSide(
                            color: AppColors.accentLight,
                            width: 2,
                          ),
                        ),
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: Responsive.width(context, 3),
                          vertical: Responsive.height(context, 1.5),
                        ),
                      ),
                      onChanged: (_) => widget.onSearchChanged(),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.filter_list),
                    onPressed: widget.onFilterPressed,
                  ),
                ],
              ),
            ),
            // Active filters row (animated separately with a short delay)
            if (showFilters)
              AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  // Fade in after the search bar is visible
                  final filtersOpacity = _controller.value.clamp(0.0, 1.0);
                  return Opacity(
                    opacity: filtersOpacity,
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: Responsive.width(context, 3),
                      ),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            Text(
                              'Active Filters: ',
                              style: AppTextStyles.bodyText1(context),
                            ),

                            if (widget.minROI != null)
                              Chip(
                                backgroundColor:
                                    Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? AppColors.greyShade800
                                    : AppColors.greyShade400,
                                label: Text('Min ROI: ${widget.minROI}%'),
                              ),
                            SizedBox(width: Responsive.width(context, 2)),
                            if (widget.maxROI != null)
                              Chip(
                                backgroundColor:
                                    Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? AppColors.greyShade800
                                    : AppColors.greyShade400,
                                label: Text('Max ROI: ${widget.maxROI}%'),
                              ),
                            SizedBox(width: Responsive.width(context, 2)),
                            if (widget.riskLevel != null)
                              Chip(
                                backgroundColor:
                                    Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? AppColors.primaryDark.withOpacity(0.2)
                                    : AppColors.riskMedium.withOpacity(0.2),
                                label: Text(
                                  'Risk: ${widget.riskLevel}',
                                  style: AppTextStyles.bodyText2(context)
                                      .copyWith(
                                        color: widget.riskLevel == 'Low'
                                            ? AppColors.riskLow
                                            : widget.riskLevel == 'Medium'
                                            ? AppColors.riskMedium
                                            : AppColors.riskHigh,
                                      ),
                                ),
                              ),
                            SizedBox(width: Responsive.width(context, 2)),
                            if (widget.industry != null)
                              Chip(
                                backgroundColor:
                                    Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? AppColors.greyShade800
                                    : AppColors.greyShade400,
                                label: Text(
                                  'Industry: ${widget.industry}',
                                  style: AppTextStyles.bodyText2(context),
                                ),
                              ),
                            SizedBox(width: Responsive.width(context, 2)),
                            TextButton(
                              onPressed: widget.onClearFilters,
                              child: Text(
                                'Clear All',
                                style: AppTextStyles.bodyText2(context),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}
