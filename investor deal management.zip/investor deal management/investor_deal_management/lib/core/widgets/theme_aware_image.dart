import '../constants/export.dart';

class ThemeAwareImage extends StatefulWidget {
  final String lightAsset;
  final String darkAsset;
  final double? width;
  final double? height;
  final BoxFit? fit;
  final Duration duration;

  const ThemeAwareImage({
    Key? key,
    required this.lightAsset,
    required this.darkAsset,
    this.width,
    this.height,
    this.fit,
    this.duration = const Duration(milliseconds: 600),
  }) : super(key: key);

  @override
  State<ThemeAwareImage> createState() => _ThemeAwareImageState();
}

class _ThemeAwareImageState extends State<ThemeAwareImage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);
    _fade = Tween<double>(begin: 0.0, end: 1.0).animate(_controller);
    _scale = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return FadeTransition(
      opacity: _fade,
      child: ScaleTransition(
        scale: _scale,
        child: Image.asset(
          isDark ? widget.darkAsset : widget.lightAsset,
          width: widget.width,
          height: widget.height,
          fit: widget.fit,
        ),
      ),
    );
  }
}
