import '../../core/constants/export.dart';

class SharedPreferencesHelper {
  final SharedPreferences prefs;

  SharedPreferencesHelper(this.prefs);

  // Auth keys
  static const String _isLoggedInKey = 'is_logged_in';
  static const String _userEmailKey = 'user_email';

  // Theme key
  static const String _isDarkModeKey = 'is_dark_mode';

  // Interest keys
  static const String _interestedDealIdsKey = 'interested_deal_ids';

  Future<bool> hasThemePreference() async {
    return prefs.containsKey(_isDarkModeKey);
  }

  // Auth methods
  Future<bool> isLoggedIn() async {
    return prefs.getBool(_isLoggedInKey) ?? false;
  }

  Future<void> setLoggedIn(bool value) async {
    await prefs.setBool(_isLoggedInKey, value);
  }

  Future<String?> getUserEmail() async {
    return prefs.getString(_userEmailKey);
  }

  Future<void> setUserEmail(String email) async {
    await prefs.setString(_userEmailKey, email);
  }

  Future<void> clearSession() async {
    await prefs.setBool(_isLoggedInKey, false);
    await prefs.remove(_userEmailKey);
  }

  // Theme methods
  Future<bool> isDarkMode() async {
    return prefs.getBool(_isDarkModeKey) ?? false;
  }

  Future<void> setDarkMode(bool isDark) async {
    await prefs.setBool(_isDarkModeKey, isDark);
  }

  // Interest methods
  Future<List<String>> getInterestedDealIds() async {
    return prefs.getStringList(_interestedDealIdsKey) ?? [];
  }

  Future<void> saveInterestedDealIds(List<String> ids) async {
    await prefs.setStringList(_interestedDealIdsKey, ids);
  }
}
