import '../../core/constants/export.dart';

final List<Deal> dealsMockData = [
  Deal(
    id: '1',
    companyName: 'EcoEnergy Solutions',
    industry: 'Energy',
    investmentRequired: 5000000,
    expectedROI: 15.5,
    riskLevel: 'Medium',
    status: 'Open',
    overview:
        'EcoEnergy Solutions is a leading renewable energy company specializing in solar and wind power generation. With projects across 5 states, we are expanding our operations to meet growing demand.',
    financialHighlights:
        'Revenue: ₹20Cr | EBITDA: ₹5Cr | Net Profit: ₹2Cr | Debt: ₹8Cr',
    roiProjection: [12.0, 14.5, 15.5, 17.0, 18.5],
  ),
  Deal(
    id: '2',
    companyName: 'FinTech Innovations',
    industry: 'Fintech',
    investmentRequired: 2500000,
    expectedROI: 22.0,
    riskLevel: 'High',
    status: 'Open',
    overview:
        'Digital payment platform targeting Tier-2 cities. Our user base has grown 300% YoY.',
    financialHighlights:
        'Revenue: ₹8Cr | EBITDA: ₹1.5Cr | Net Profit: ₹0.8Cr | Debt: ₹2Cr',
    roiProjection: [18.0, 22.0, 25.0, 28.0, 30.0],
  ),
  Deal(
    id: '3',
    companyName: 'HealthCare Plus',
    industry: 'Healthcare',
    investmentRequired: 8000000,
    expectedROI: 12.0,
    riskLevel: 'Low',
    status: 'Closed',
    overview:
        'Chain of diagnostic centers with 15 locations. Stable revenue model with government contracts.',
    financialHighlights:
        'Revenue: ₹35Cr | EBITDA: ₹10Cr | Net Profit: ₹5Cr | Debt: ₹12Cr',
    roiProjection: [10.0, 11.0, 12.0, 12.5, 13.0],
  ),
  Deal(
    id: '4',
    companyName: 'AgriTech Grow',
    industry: 'Agritech',
    investmentRequired: 12000000,
    expectedROI: 18.0,
    riskLevel: 'Medium',
    status: 'Open',
    overview:
        'IoT-based farming solutions. Helping farmers increase yield by 40%.',
    financialHighlights:
        'Revenue: ₹15Cr | EBITDA: ₹4Cr | Net Profit: ₹2Cr | Debt: ₹5Cr',
    roiProjection: [14.0, 16.0, 18.0, 20.0, 22.0],
  ),
  Deal(
    id: '5',
    companyName: 'EdTech Learn',
    industry: 'Edtech',
    investmentRequired: 3500000,
    expectedROI: 25.0,
    riskLevel: 'High',
    status: 'Open',
    overview:
        'Online learning platform for professional courses. 500k+ active users.',
    financialHighlights:
        'Revenue: ₹12Cr | EBITDA: ₹3Cr | Net Profit: ₹1Cr | Debt: ₹4Cr',
    roiProjection: [20.0, 23.0, 25.0, 28.0, 30.0],
  ),
  Deal(
    id: '6',
    companyName: 'LogiSwift',
    industry: 'Logistics',
    investmentRequired: 15000000,
    expectedROI: 14.0,
    riskLevel: 'Low',
    status: 'Closed',
    overview:
        'Last-mile delivery network with 200+ franchises. Profitable for 3 years.',
    financialHighlights:
        'Revenue: ₹45Cr | EBITDA: ₹12Cr | Net Profit: ₹6Cr | Debt: ₹15Cr',
    roiProjection: [12.0, 13.0, 14.0, 14.5, 15.0],
  ),
];
