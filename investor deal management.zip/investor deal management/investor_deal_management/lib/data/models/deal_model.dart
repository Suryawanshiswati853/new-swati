class Deal {
  final String id;
  final String companyName;
  final String industry;
  final double investmentRequired;
  final double expectedROI;
  final String riskLevel;
  final String status;
  final String overview;
  final String financialHighlights;
  final List<double> roiProjection; 

  Deal({
    required this.id,
    required this.companyName,
    required this.industry,
    required this.investmentRequired,
    required this.expectedROI,
    required this.riskLevel,
    required this.status,
    required this.overview,
    required this.financialHighlights,
    required this.roiProjection,
  });

  factory Deal.fromJson(Map<String, dynamic> json) {
    return Deal(
      id: json['id'],
      companyName: json['companyName'],
      industry: json['industry'],
      investmentRequired: json['investmentRequired'].toDouble(),
      expectedROI: json['expectedROI'].toDouble(),
      riskLevel: json['riskLevel'],
      status: json['status'],
      overview: json['overview'],
      financialHighlights: json['financialHighlights'],
      roiProjection: List<double>.from(json['roiProjection']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'companyName': companyName,
      'industry': industry,
      'investmentRequired': investmentRequired,
      'expectedROI': expectedROI,
      'riskLevel': riskLevel,
      'status': status,
      'overview': overview,
      'financialHighlights': financialHighlights,
      'roiProjection': roiProjection,
    };
  }
}