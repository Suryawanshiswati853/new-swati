import '../../core/constants/export.dart';




class AuthRepository {
  final SharedPreferencesHelper prefsHelper;

  AuthRepository(this.prefsHelper);

  Future<bool> isLoggedIn() async {
    return await prefsHelper.isLoggedIn();
  }

  Future<User> login(String email, String password) async {
    // Mock login - accept any non-empty email and password
    await Future.delayed(const Duration(milliseconds: 500));
    
    if (email.isEmpty || password.isEmpty) {
      throw Exception('Email and password are required');
    }
    
    // Mock success
    final user = User(email: email);
    await prefsHelper.setLoggedIn(true);
    await prefsHelper.setUserEmail(email);
    return user;
  }

  Future<void> logout() async {
    await prefsHelper.clearSession();
  }

  Future<User> getCurrentUser() async {
    final email = await prefsHelper.getUserEmail();
    return User(email: email ?? 'user@example.com');
  }
}