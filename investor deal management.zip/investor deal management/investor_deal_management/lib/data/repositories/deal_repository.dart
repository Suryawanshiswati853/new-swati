import '../../core/constants/export.dart';


class DealRepository {
  Future<List<Deal>> fetchDeals() async {
    // Simulate network delay
    await Future.delayed(const Duration(milliseconds: 800));
    
    // Load from local JSON asset
    try {
      final jsonString = await rootBundle.loadString('assets/deals.json');
      final List<dynamic> jsonList = json.decode(jsonString);
      return jsonList.map((json) => Deal.fromJson(json)).toList();
    } catch (e) {
      return dealsMockData;
    }
  }
}