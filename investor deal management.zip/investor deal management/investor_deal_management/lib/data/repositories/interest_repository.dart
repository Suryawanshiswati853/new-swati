import '../../core/constants/export.dart';



class InterestRepository {
  final SharedPreferencesHelper prefsHelper;

  InterestRepository(this.prefsHelper);

  Future<Set<String>> getInterestedDealIds() async {
    final ids = await prefsHelper.getInterestedDealIds();
    return Set<String>.from(ids);
  }

  Future<void> saveInterestedDealIds(Set<String> ids) async {
    await prefsHelper.saveInterestedDealIds(ids.toList());
  }
}