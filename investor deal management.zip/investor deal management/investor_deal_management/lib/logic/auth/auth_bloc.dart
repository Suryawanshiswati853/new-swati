import '../../core/constants/export.dart';
part 'auth_event.dart';
part 'auth_state.dart';



/// BLoC that manages authentication state.
/// It handles:
/// - Checking if a user is already logged in (on app start)
/// - Logging in with email/password
/// - Logging out
///
/// Emits:
/// - [AuthLoading] while processing
/// - [AuthAuthenticated] on successful login or if already logged in
/// - [AuthUnauthenticated] when logged out or no session exists
/// - [AuthError] if login fails
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  /// Repository that handles authentication logic (local storage, mock API).
  final AuthRepository authRepository;

  /// Constructor. Requires an [AuthRepository] instance.
  /// Initial state is [AuthInitial].
  AuthBloc({required this.authRepository}) : super(AuthInitial()) {
    // Register event handlers
    on<CheckAuthStatus>(_onCheckAuthStatus);
    on<LoginRequested>(_onLoginRequested);
    on<LogoutRequested>(_onLogoutRequested);
  }

  /// Handles [CheckAuthStatus] event.
  /// Called when the app starts or when we need to verify the session.
  ///
  /// 1. Checks [authRepository.isLoggedIn()] (e.g., from SharedPreferences).
  /// 2. If true, fetches the current user and emits [AuthAuthenticated].
  /// 3. Otherwise emits [AuthUnauthenticated].
  Future<void> _onCheckAuthStatus(
    CheckAuthStatus event,
    Emitter<AuthState> emit,
  ) async {
    final isLoggedIn = await authRepository.isLoggedIn();
    if (isLoggedIn) {
      final user = await authRepository.getCurrentUser();
      emit(AuthAuthenticated(user));
    } else {
      emit(AuthUnauthenticated());
    }
  }

  /// Handles [LoginRequested] event.
  /// Called when the user submits the login form.
  ///
  /// 1. Emits [AuthLoading] to show a loading indicator.
  /// 2. Attempts to log in via [authRepository.login()].
  /// 3. On success, emits [AuthAuthenticated] with the user object.
  /// 4. On failure, catches the error and emits [AuthError] with the error message.
  Future<void> _onLoginRequested(
    LoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final user = await authRepository.login(event.email, event.password);
      emit(AuthAuthenticated(user));
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  /// Handles [LogoutRequested] event.
  /// Called when the user taps the logout button.
  ///
  /// 1. Calls [authRepository.logout()] to clear the session.
  /// 2. Emits [AuthUnauthenticated] to redirect to the login screen.
  Future<void> _onLogoutRequested(
    LogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    await authRepository.logout();
    emit(AuthUnauthenticated());
  }
}