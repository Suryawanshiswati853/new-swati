part of 'auth_bloc.dart';


/// Base class for all authentication events.
abstract class AuthEvent extends Equatable {
  const AuthEvent();

  @override
  List<Object?> get props => [];
}

/// Event triggered when the user attempts to log in.
/// Contains the email and password entered by the user.
class LoginRequested extends AuthEvent {
  final String email;
  final String password;

  const LoginRequested({required this.email, required this.password});

  @override
  List<Object?> get props => [email, password];
}

/// Event triggered when the user requests to log out.
class LogoutRequested extends AuthEvent {}

/// Event triggered when the app starts or the authentication status needs to be verified.
/// The BLoC will check local storage (SharedPreferences) to see if a user is already logged in.
class CheckAuthStatus extends AuthEvent {}