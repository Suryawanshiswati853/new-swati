
part of 'auth_bloc.dart';

/// Base class for all authentication states.
abstract class AuthState extends Equatable {
  const AuthState();

  @override
  List<Object?> get props => [];
}

/// Initial state before any authentication action has been performed.
class AuthInitial extends AuthState {}

/// State indicating that an authentication operation (login, logout, or check) is in progress.
/// Useful for showing a loading indicator in the UI.
class AuthLoading extends AuthState {}

/// State representing a successful authentication.
/// Contains the [User] object with user details (email, name, etc.).
/// The UI should navigate to the home screen when this state is emitted.
class AuthAuthenticated extends AuthState {
  final User user;

  const AuthAuthenticated(this.user);

  @override
  List<Object?> get props => [user];
}

/// State representing that no user is currently authenticated.
/// The UI should show the login screen when this state is emitted.
class AuthUnauthenticated extends AuthState {}

/// State representing an authentication error.
/// The UI should display the error message to the user.
class AuthError extends AuthState {
  final String message;

  const AuthError(this.message);

  @override
  List<Object?> get props => [message];
}