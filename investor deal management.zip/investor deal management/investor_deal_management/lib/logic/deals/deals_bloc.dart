import '../../core/constants/export.dart';




part 'deals_event.dart';
part 'deals_state.dart';

class DealBloc extends Bloc<DealEvent, DealState> {
  final DealRepository dealRepository;

  DealBloc({required this.dealRepository}) : super(DealInitial()) {
    on<LoadDeals>(_onLoadDeals);
    on<UpdateFilters>(_onUpdateFilters);
    on<ClearFilters>(_onClearFilters);
  }

  Future<void> _onLoadDeals(
    LoadDeals event,
    Emitter<DealState> emit,
  ) async {
    emit(DealLoading());
    try {
      final deals = await dealRepository.fetchDeals();
      emit(DealLoaded(
        allDeals: deals,
        filteredDeals: deals,
      ));
    } catch (e) {
      emit(DealError(e.toString()));
    }
  }

  void _onUpdateFilters(
    UpdateFilters event,
    Emitter<DealState> emit,
  ) {
    if (state is DealLoaded) {
      final currentState = state as DealLoaded;
      final filtered = FilterUtils.applyFilters(
        deals: currentState.allDeals,
        searchQuery: event.searchQuery,
        minROI: event.minROI,
        maxROI: event.maxROI,
        riskLevel: event.riskLevel,
        industry: event.industry,
      );
      emit(DealLoaded(
        allDeals: currentState.allDeals,
        filteredDeals: filtered,
        searchQuery: event.searchQuery,
        minROI: event.minROI,
        maxROI: event.maxROI,
        riskLevel: event.riskLevel,
        industry: event.industry,
      ));
    }
  }

  void _onClearFilters(
    ClearFilters event,
    Emitter<DealState> emit,
  ) {
    if (state is DealLoaded) {
      final currentState = state as DealLoaded;
      emit(DealLoaded(
        allDeals: currentState.allDeals,
        filteredDeals: currentState.allDeals,
        searchQuery: '',
        minROI: null,
        maxROI: null,
        riskLevel: null,
        industry: null,
      ));
    }
  }
}