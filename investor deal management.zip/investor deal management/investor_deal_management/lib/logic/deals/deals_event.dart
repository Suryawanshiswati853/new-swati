// import 'package:equatable/equatable.dart';
part of 'deals_bloc.dart';


abstract class DealEvent extends Equatable {
  const DealEvent();

  @override
  List<Object?> get props => [];
}

class LoadDeals extends DealEvent {}

class UpdateFilters extends DealEvent {
  final String searchQuery;
  final double? minROI;
  final double? maxROI;
  final String? riskLevel;
  final String? industry;

  const UpdateFilters({
    this.searchQuery = '',
    this.minROI,
    this.maxROI,
    this.riskLevel,
    this.industry,
  });

  @override
  List<Object?> get props => [searchQuery, minROI, maxROI, riskLevel, industry];
}

class ClearFilters extends DealEvent {}