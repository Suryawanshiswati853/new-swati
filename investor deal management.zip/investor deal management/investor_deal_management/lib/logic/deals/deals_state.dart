part of 'deals_bloc.dart';


abstract class DealState extends Equatable {
  const DealState();

  @override
  List<Object?> get props => [];
}

class DealInitial extends DealState {}

class DealLoading extends DealState {}

class DealLoaded extends DealState {
  final List<Deal> allDeals;
  final List<Deal> filteredDeals;
  final String searchQuery;
  final double? minROI;
  final double? maxROI;
  final String? riskLevel;
  final String? industry;

  const DealLoaded({
    required this.allDeals,
    required this.filteredDeals,
    this.searchQuery = '',
    this.minROI,
    this.maxROI,
    this.riskLevel,
    this.industry,
  });

  @override
  List<Object?> get props => [allDeals, filteredDeals, searchQuery, minROI, maxROI, riskLevel, industry];
}

class DealError extends DealState {
  final String message;

  const DealError(this.message);

  @override
  List<Object?> get props => [message];
}