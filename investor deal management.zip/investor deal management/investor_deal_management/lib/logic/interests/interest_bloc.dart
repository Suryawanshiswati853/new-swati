import '../../core/constants/export.dart';


part 'interest_event.dart';
part 'interest_state.dart';

class InterestBloc extends Bloc<InterestEvent, InterestState> {
  final InterestRepository interestRepository;

  InterestBloc({required this.interestRepository}) : super(InterestInitial()) {
    on<LoadInterests>(_onLoadInterests);
    on<AddInterest>(_onAddInterest);
    on<RemoveInterest>(_onRemoveInterest);
  }

  Future<void> _onLoadInterests(
    LoadInterests event,
    Emitter<InterestState> emit,
  ) async {
    emit(InterestLoading());
    try {
      final ids = await interestRepository.getInterestedDealIds();
      emit(InterestLoaded(ids));
    } catch (e) {
      emit(InterestError(e.toString()));
    }
  }

  Future<void> _onAddInterest(
    AddInterest event,
    Emitter<InterestState> emit,
  ) async {
    if (state is InterestLoaded) {
      final currentIds = (state as InterestLoaded).interestedIds;
      final updatedIds = Set<String>.from(currentIds)..add(event.dealId);
      await interestRepository.saveInterestedDealIds(updatedIds);
      emit(InterestLoaded(updatedIds));
    }
  }

  Future<void> _onRemoveInterest(
    RemoveInterest event,
    Emitter<InterestState> emit,
  ) async {
    if (state is InterestLoaded) {
      final currentIds = (state as InterestLoaded).interestedIds;
      final updatedIds = Set<String>.from(currentIds)..remove(event.dealId);
      await interestRepository.saveInterestedDealIds(updatedIds);
      emit(InterestLoaded(updatedIds));
    }
  }
}