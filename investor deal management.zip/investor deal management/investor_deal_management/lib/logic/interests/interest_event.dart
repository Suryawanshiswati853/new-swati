// lib/bloc/interest/interest_event.dart
part of 'interest_bloc.dart';

abstract class InterestEvent extends Equatable {
  const InterestEvent();

  @override
  List<Object?> get props => [];
}

class LoadInterests extends InterestEvent {}

class AddInterest extends InterestEvent {
  final String dealId;

  const AddInterest(this.dealId);

  @override
  List<Object?> get props => [dealId];
}

class RemoveInterest extends InterestEvent {
  final String dealId;

  const RemoveInterest(this.dealId);

  @override
  List<Object?> get props => [dealId];
}