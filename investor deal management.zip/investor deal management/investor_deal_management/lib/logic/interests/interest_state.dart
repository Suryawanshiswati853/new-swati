// lib/bloc/interest/interest_state.dart
part of 'interest_bloc.dart';

abstract class InterestState extends Equatable {
  const InterestState();

  @override
  List<Object?> get props => [];
}

class InterestInitial extends InterestState {}

class InterestLoading extends InterestState {}

class InterestLoaded extends InterestState {
  final Set<String> interestedIds;

  const InterestLoaded(this.interestedIds);

  @override
  List<Object?> get props => [interestedIds];
}

class InterestError extends InterestState {
  final String message;

  const InterestError(this.message);

  @override
  List<Object?> get props => [message];
}