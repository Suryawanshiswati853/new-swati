import 'core/constants/export.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late SharedPreferencesHelper sharedPrefsHelper;
  late AuthRepository authRepository;
  late InterestRepository interestRepository;
  late DealRepository dealRepository;

  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _initDependencies();
  }

  Future<void> _initDependencies() async {
    final prefs = await SharedPreferences.getInstance();
    sharedPrefsHelper = SharedPreferencesHelper(prefs);
    authRepository = AuthRepository(sharedPrefsHelper);
    interestRepository = InterestRepository(sharedPrefsHelper);
    dealRepository = DealRepository();

    setState(() {
      _isInitialized = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return const MaterialApp(
        home: Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }

    return MultiBlocProvider(
      providers: [
        // ThemeCubit removed – we no longer need it
        BlocProvider(create: (_) => AuthBloc(authRepository: authRepository)),
        BlocProvider(
          create: (_) =>
              DealBloc(dealRepository: dealRepository)..add(LoadDeals()),
        ),
        BlocProvider(
          create: (_) =>
              InterestBloc(interestRepository: interestRepository)
                ..add(LoadInterests()),
        ),
      ],
      child: MaterialApp(
        title: 'Investor Deal Manager',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        home: Builder(
          builder: (context) {
            return BlocBuilder<AuthBloc, AuthState>(
              builder: (context, authState) {
                if (authState is AuthAuthenticated) {
                  return const HomeScreen();
                }
                return const LoginScreen();
              },
            );
          },
        ),
      ),
    );
  }
}

