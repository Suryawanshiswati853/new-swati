import '../../core/constants/export.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: Responsive.symmetric(
            context: context,
            horizontalPercent: 8,
            verticalPercent: 5,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ThemeAwareImage(
                  lightAsset: AppAssets.logoLight,
                  darkAsset: AppAssets.logoDark,
                  width: Responsive.width(context, 60),
                  height: Responsive.height(context, 15),
                  duration: const Duration(milliseconds: 700),
                  // beginScale: 0.7,
                ),

                AnimatedText(
                  text: 'Investor Deal Manager',
                  style: AppTextStyles.headline1(context),
                  textAlign: TextAlign.center,
                  beginOffset: const Offset(-0.3, 0),
                  beginScale: 0.7,
                  endScale: 1.0,
                  duration: const Duration(milliseconds: 800),
                  outlineColor: AppColors.accentLight, // outline colour
                  outlineWidth: 2.0, // thickness
                  glowColorLight: AppColors.accentLight, // glow in light mode
                  glowColorDark: AppColors.accentDark, // glow in dark mode
                  glowRadius: 12.0,
                ),

                SizedBox(height: Responsive.height(context, 2)),
                AnimatedText(
                  text: 'Sign in to continue',
                  style: AppTextStyles.bodyText2(context),
                  textAlign: TextAlign.center,
                  beginOffset: const Offset(-0.3, 0),
                  beginScale: 0.7,
                  endScale: 1.0,
                  duration: const Duration(milliseconds: 800),
                  glowColorLight:
                      AppColors.accentLight, // greenish accent in light mode
                  glowColorDark:
                      AppColors.accentDark, // bright green in dark mode
                  glowRadius: 12.0,
                ),

                SizedBox(height: Responsive.height(context, 8)),
                CustomTextFormField(
                  autovalidateMode: AutovalidateMode.onUserInteraction,

                  controller: _emailController,
                  labelText: 'Email',
                  prefixIcon: Icons.email_outlined,
                  keyboardType: TextInputType.emailAddress,
                  validator: AppValidators.validateEmail,
                ),
                SizedBox(height: Responsive.height(context, 2)),
                CustomTextFormField(
                  autovalidateMode: AutovalidateMode.onUserInteraction,

                  controller: _passwordController,
                  isPassword: true, // enables toggle eye icon
                  labelText: 'Password',
                  prefixIcon: Icons.lock_outline,
                  obscureText: true,
                  validator: AppValidators.validatePassword,
                ),
                SizedBox(height: Responsive.height(context, 6)),
                BlocConsumer<AuthBloc, AuthState>(
                  listener: (context, state) {
                    if (state is AuthError) {
                      AppSnackBar.show(
                        context: context,
                        message: state.message,
                      );
                    }
                  },
                  builder: (context, state) {
                    return CustomButton(
                      text: 'Login',
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          context.read<AuthBloc>().add(
                            LoginRequested(
                              email: _emailController.text,
                              password: _passwordController.text,
                            ),
                          );
                        }
                      },
                      isLoading: state is AuthLoading,
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
