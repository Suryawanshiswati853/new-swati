import '../../core/constants/export.dart';

class DealDetailsScreen extends StatefulWidget {
  final Deal deal;

  const DealDetailsScreen({Key? key, required this.deal}) : super(key: key);

  @override
  State<DealDetailsScreen> createState() => _DealDetailsScreenState();
}

class _DealDetailsScreenState extends State<DealDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.deal.companyName), elevation: 0),
      body: SingleChildScrollView(
        padding: Responsive.symmetric(
          context: context,
          horizontalPercent: 4,
          verticalPercent: 2,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Company Overview Card
            AnimatedSectionCard(
              title: 'Company Overview',
              icon: Icons.business_outlined, // optional icon
              showAccentBar: true,
              content: Text(
                widget.deal.overview,
                style: AppTextStyles.bodyText1(context),
              ),
            ),
            SizedBox(height: Responsive.height(context, 2)),

            // Financial Highlights Card
            AnimatedSectionCard(
              icon: Icons.business_center_outlined,
              title: 'Financial Highlights',
              delay: const Duration(milliseconds: 150),
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildFinancialHighlights(
                    context,
                    widget.deal.financialHighlights,
                  ),

                  SizedBox(height: Responsive.height(context, 2)),
                  _buildInfoRow(
                    context,
                    'Investment Required',
                    '₹${(widget.deal.investmentRequired / 100000).toStringAsFixed(0)}L',
                    icon: Icons.currency_rupee_outlined,
                  ),
                  _buildInfoRow(
                    context,
                    'Expected ROI',
                    '${widget.deal.expectedROI.toStringAsFixed(1)}%',
                    icon: Icons.trending_up_outlined,
                  ),
                  _buildInfoRow(
                    context,
                    'Risk Level',
                    widget.deal.riskLevel,
                    isRisk: true,
                    icon: Icons.warning_amber_outlined,
                  ),
                  _buildInfoRow(
                    context,
                    'Status',
                    widget.deal.status,
                    isStatus: true,
                    icon: Icons.info_outline,
                  ),
                ],
              ),
            ),
            SizedBox(height: Responsive.height(context, 2)),

            // ROI Projection Graph Card
            // ROI Projection (Next 5 Years) – now using AnimatedSectionCard
            AnimatedSectionCard(
              title: 'ROI Projection (Next 5 Years)',
              icon: Icons.show_chart, // optional icon
              showAccentBar: true, // keep accent bar
              delay: const Duration(
                milliseconds: 300,
              ), // stagger after financial card
              content: RoiProjectionGraph(
                projections: widget.deal.roiProjection,
                // optional customizations like chart color
              ),
            ),
            SizedBox(height: Responsive.height(context, 3)),

            // Express Interest Button
            BlocBuilder<InterestBloc, InterestState>(
              builder: (context, state) {
                final isInterested =
                    state is InterestLoaded &&
                    state.interestedIds.contains(widget.deal.id);
                return CustomButton(
                  text: isInterested ? 'Interested ✓' : "I'm Interested",
                  onPressed: isInterested
                      ? null
                      : () {
                          context.read<InterestBloc>().add(
                            AddInterest(widget.deal.id),
                          );
                          AppSnackBar.show(
                            context: context,
                            message:
                                'Added ${widget.deal.companyName} to your interests',
                          );
                        },
                  icon: isInterested
                      ? Icons.favorite_outlined
                      : Icons.favorite_border,
                );
              },
            ),
            SizedBox(height: Responsive.height(context, 2)),
          ],
        ),
      ),
    );
  }

  Widget _buildFinancialHighlights(BuildContext context, String highlights) {
    final parts = highlights.split(' | ').map((part) => part.trim()).toList();

    if (parts.length != 4) {
      return Text(highlights, style: AppTextStyles.bodyText1(context));
    }

    final revenue = parts[0];
    final ebitda = parts[1];
    final netProfit = parts[2];
    final debt = parts[3];

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: _buildHighlightItem(
                context,
                revenue,
                Icons.currency_rupee,
              ),
            ),
            SizedBox(width: Responsive.width(context, 4)),
            Expanded(
              child: _buildHighlightItem(
                context,
                ebitda,
                Icons.trending_up_outlined,
              ),
            ),
          ],
        ),
        SizedBox(height: Responsive.height(context, 1.5)),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: _buildHighlightItem(
                context,
                netProfit,
                Icons.account_balance_outlined,
              ),
            ),
            SizedBox(width: Responsive.width(context, 4)),
            Expanded(
              child: _buildHighlightItem(
                context,
                debt,
                Icons.credit_card_outlined,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildHighlightItem(BuildContext context, String text, IconData icon) {
    final parts = text.split(':');
    final label = parts[0].trim();
    final value = parts[1].trim();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Icon(
          icon,
          size: Responsive.fontSize(context, 6),
          color: AppColors.accentLight,
        ),
        SizedBox(width: Responsive.width(context, 2)),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: AppTextStyles.caption2(context).copyWith(
                  fontWeight: FontWeight.w800,
                  color: isDark
                      ? AppColors.backgroundLight
                      : AppColors.primaryLight,
                ),
              ),
              SizedBox(height: Responsive.height(context, 0.5)),
              Text(
                value,
                style: AppTextStyles.bodyText1(context).copyWith(
                  fontWeight: FontWeight.w800,
                  color: isDark
                      ? AppColors.greyShade400
                      : AppColors.greyShade600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(
    BuildContext context,
    String label,
    String value, {
    bool isRisk = false,
    bool isStatus = false,
    IconData? icon, // new optional parameter
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    Color? valueColor;
    if (isRisk) {
      if (value == 'Low')
        valueColor = AppColors.riskLow;
      else if (value == 'Medium')
        valueColor = AppColors.riskMedium;
      else if (value == 'High')
        valueColor = AppColors.riskHigh;
    }
    if (isStatus) {
      valueColor = value == 'Open'
          ? AppColors.statusOpen
          : AppColors.statusClosed;
    }

    return Padding(
      padding: EdgeInsets.symmetric(vertical: Responsive.height(context, 1)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(
                  icon,
                  size: Responsive.fontSize(context, 5),
                  color: AppColors.accentLight,
                ),
                SizedBox(width: Responsive.width(context, 2)),
              ],
              Text(
                label,
                style: AppTextStyles.bodyText2(context).copyWith(
                  color: isDark
                      ? AppColors.backgroundLight
                      : AppColors.greyShade600,
                ),
              ),
            ],
          ),
          // Right side: value
          Text(
            value,
            style: TextStyle(
              fontSize: Responsive.fontSize(context, 4),
              fontWeight: FontWeight.bold,
              color:
                  valueColor ??
                  (isDark ? AppColors.greyShade400 : AppColors.greyShade600),
            ),
          ),
        ],
      ),
    );
  }
}
