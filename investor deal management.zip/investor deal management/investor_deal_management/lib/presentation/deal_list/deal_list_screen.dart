import '../../core/constants/export.dart';

class DealListScreen extends StatefulWidget {
  const DealListScreen({Key? key}) : super(key: key);

  @override
  State<DealListScreen> createState() => _DealListScreenState();
}

class _DealListScreenState extends State<DealListScreen> {
  final _searchController = TextEditingController();
  String _searchQuery = '';
  double? _minROI;
  double? _maxROI;
  String? _riskLevel;
  String? _industry;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    setState(() {
      _searchQuery = _searchController.text;
    });

    _applyFilters();
  }

  void _applyFilters() {
    context.read<DealBloc>().add(
      UpdateFilters(
        searchQuery: _searchQuery,
        minROI: _minROI,
        maxROI: _maxROI,
        riskLevel: _riskLevel,
        industry: _industry,
      ),
    );
  }

  void _clearFilters() {
    setState(() {
      _searchQuery = '';
      _searchController.text = '';
      _minROI = null;
      _maxROI = null;
      _riskLevel = null;
      _industry = null;
    });
    context.read<DealBloc>().add(ClearFilters());
  }

  void _openFilterSheet() {
    // Local copies of current filters
    double? localMinROI = _minROI;
    double? localMaxROI = _maxROI;
    String? localRiskLevel = _riskLevel;
    String? localIndustry = _industry;

    // Controllers for the text fields
    final minROIController = TextEditingController(
      text: localMinROI?.toString() ?? '',
    );
    final maxROIController = TextEditingController(
      text: localMaxROI?.toString() ?? '',
    );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateSheet) {
            final isDark = Theme.of(context).brightness == Brightness.dark;
            final industries = context.read<DealBloc>().state is DealLoaded
                ? (context.read<DealBloc>().state as DealLoaded).allDeals
                      .map((d) => d.industry)
                      .toSet()
                      .toList()
                : [];

            return Container(
              padding: EdgeInsets.all(Responsive.width(context, 5)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Text(
                        'Filter Deals',
                        style: AppTextStyles.headline2(context),
                      ),
                      const Spacer(),
                      IconButton(
                        icon: Icon(
                          Icons.clear_outlined,
                          color: isDark ? Colors.white70 : Colors.black54,
                        ),
                        onPressed: () => Navigator.pop(context),
                        tooltip: 'Close',
                      ),
                    ],
                  ),
                  SizedBox(height: Responsive.height(context, 3)),
                  Text(
                    'ROI Range (%)',
                    style: AppTextStyles.bodyText1(context),
                  ),
                  SizedBox(height: Responsive.height(context, 1)),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: minROIController,
                          decoration: InputDecoration(
                            labelText: 'Min ROI',
                            labelStyle: AppTextStyles.bodyText2(context),
                          ),
                          keyboardType: TextInputType.number,
                          style: AppTextStyles.bodyText1(context),
                          onChanged: (value) {
                            setStateSheet(() {
                              localMinROI = double.tryParse(value);
                            });
                          },
                        ),
                      ),
                      SizedBox(width: Responsive.width(context, 4)),
                      Expanded(
                        child: TextField(
                          controller: maxROIController,
                          decoration: InputDecoration(
                            labelText: 'Max ROI',
                            labelStyle: AppTextStyles.bodyText2(context),
                          ),
                          keyboardType: TextInputType.number,
                          style: AppTextStyles.bodyText1(context),
                          onChanged: (value) {
                            setStateSheet(() {
                              localMaxROI = double.tryParse(value);
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: Responsive.height(context, 3)),
                  Text('Risk Level', style: AppTextStyles.bodyText1(context)),
                  SizedBox(height: Responsive.height(context, 1)),
                  Wrap(
                    spacing: Responsive.width(context, 2),
                    children: ['Low', 'Medium', 'High'].map((risk) {
                      return FilterChip(
                        label: Text(
                          risk,
                          style: AppTextStyles.bodyText2(context),
                        ),
                        selected: localRiskLevel == risk,
                        onSelected: (selected) => setStateSheet(() {
                          localRiskLevel = selected ? risk : null;
                        }),
                        backgroundColor: isDark
                            ? Colors.grey[800]
                            : Colors.grey[200],
                        selectedColor: AppColors.accentLight.withOpacity(0.3),
                        checkmarkColor: AppColors.accentLight,
                      );
                    }).toList(),
                  ),
                  SizedBox(height: Responsive.height(context, 3)),
                  Text('Industry', style: AppTextStyles.bodyText1(context)),
                  SizedBox(height: Responsive.height(context, 1)),
                  Wrap(
                    spacing: Responsive.width(context, 2),
                    children: industries.map((industry) {
                      return FilterChip(
                        label: Text(
                          industry,
                          style: AppTextStyles.bodyText2(context),
                        ),
                        selected: localIndustry == industry,
                        onSelected: (selected) => setStateSheet(() {
                          localIndustry = selected ? industry : null;
                        }),
                        backgroundColor: isDark
                            ? Colors.grey[800]
                            : Colors.grey[200],
                        selectedColor: AppColors.accentLight.withOpacity(0.3),
                        checkmarkColor: AppColors.accentLight,
                      );
                    }).toList(),
                  ),
                  SizedBox(height: Responsive.height(context, 5)),
                  Row(
                    children: [
                      Expanded(
                        child: CustomButton(
                          text: 'Clear All',
                          onPressed: () {
                            setStateSheet(() {
                              localMinROI = null;
                              localMaxROI = null;
                              localRiskLevel = null;
                              localIndustry = null;
                              minROIController.clear();
                              maxROIController.clear();
                            });
                          },
                          isOutlined: true,
                        ),
                      ),
                      SizedBox(width: Responsive.width(context, 4)),
                      Expanded(
                        child: CustomButton(
                          text: 'Apply',
                          onPressed: () {
                            setState(() {
                              _minROI = localMinROI;
                              _maxROI = localMaxROI;
                              _riskLevel = localRiskLevel;
                              _industry = localIndustry;
                            });
                            _applyFilters();
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: Responsive.height(context, 2)),
          SearchAndFilterBar(
            searchController: _searchController,
            searchQuery: _searchQuery,
            onSearchChanged: _onSearchChanged,
            onFilterPressed: _openFilterSheet,
            minROI: _minROI,
            maxROI: _maxROI,
            riskLevel: _riskLevel,
            industry: _industry,
            onClearFilters: _clearFilters,
          ),
          Expanded(
            child: BlocBuilder<DealBloc, DealState>(
              builder: (context, state) {
                if (state is DealLoading) {
                  return const CustomLoadingWidget();
                } else if (state is DealError) {
                  return ErrorDisplayWidget(
                    message: state.message,
                    onRetry: () => context.read<DealBloc>().add(LoadDeals()),
                  );
                } else if (state is DealLoaded) {
                  if (state.filteredDeals.isEmpty) {
                    return const EmptyStateWidget(
                      title: 'No Deals Found',
                      subtitle: 'Try adjusting your filters',
                    );
                  }
                  return ListView.builder(
                    itemCount: state.filteredDeals.length,
                    padding: EdgeInsets.symmetric(
                      vertical: Responsive.height(context, 1),
                    ),
                    itemBuilder: (context, index) {
                      final deal = state.filteredDeals[index];
                      return DealCard(
                        deal: deal,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DealDetailsScreen(deal: deal),
                          ),
                        ),
                      );
                    },
                  );
                }
                return const SizedBox.shrink();
              },
            ),
          ),
        ],
      ),
    );
  }
}
