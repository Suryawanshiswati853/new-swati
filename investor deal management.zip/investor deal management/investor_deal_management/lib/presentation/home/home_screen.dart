import '../../core/constants/export.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  void _onDrawerItemSelected(int index) {
    setState(() {
      _selectedIndex = index;
    });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final authState = context.watch<AuthBloc>().state;
    final user = authState is AuthAuthenticated ? authState.user : null;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _selectedIndex == 0 ? 'Investment Deals' : 'My Interests',
          style: AppTextStyles.headline2(
            context,
          ).copyWith(color: isDark ? AppColors.cardLight : AppColors.cardLight),
        ),
      ),
      drawer: CustomDrawer(
        user: user,
        selectedIndex: _selectedIndex,
        onItemSelected: _onDrawerItemSelected,
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: const [DealListScreen(), MyInterestsScreen()],
      ),
    );
  }
}
