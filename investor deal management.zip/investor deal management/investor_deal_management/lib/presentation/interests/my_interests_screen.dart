import '../../core/constants/export.dart';

class MyInterestsScreen extends StatelessWidget {
  const MyInterestsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<DealBloc, DealState>(
        builder: (context, dealState) {
          if (dealState is DealLoading) {
            return const CustomLoadingWidget();
          }

          if (dealState is DealLoaded) {
            return BlocBuilder<InterestBloc, InterestState>(
              builder: (context, interestState) {
                if (interestState is InterestLoading) {
                  return const CustomLoadingWidget();
                }

                if (interestState is InterestLoaded) {
                  final interestedDeals = dealState.allDeals
                      .where(
                        (deal) => interestState.interestedIds.contains(deal.id),
                      )
                      .toList();

                  if (interestedDeals.isEmpty) {
                    return const EmptyStateWidget(
                      title: 'No Interests Yet',
                      subtitle: 'Tap "I\'m Interested" on any deal to add here',
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.symmetric(
                      vertical: Responsive.height(context, 1),
                    ),
                    itemCount: interestedDeals.length,
                    itemBuilder: (context, index) {
                      final deal = interestedDeals[index];
                      return Stack(
                        children: [
                          DealCard(
                            deal: deal,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      DealDetailsScreen(deal: deal),
                                ),
                              );
                            },
                          ),
                          // Delete icon positioned on the right edge, vertically centered
                          Positioned(
                            right: Responsive.width(context, 2),
                            top: 0,
                            bottom: 0,
                            child: Center(
                              child: Container(
                                decoration: BoxDecoration(
                                  // color: Colors.black.withOpacity(0.7),
                                  shape: BoxShape.circle,
                                ),
                                child: IconButton(
                                  icon: Icon(
                                    Icons.delete_outline,
                                    color:
                                        Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? AppColors.backgroundLight
                                        : AppColors.backgroundDark,
                                    size: 22,
                                  ),
                                  onPressed: () {
                                    context.read<InterestBloc>().add(
                                      RemoveInterest(deal.id),
                                    );
                                    AppSnackBar.show(
                                      context: context,
                                      message:
                                          'Removed ${deal.companyName} from interests',
                                    );
                                   
                                  },
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(
                                    minWidth: 40,
                                    minHeight: 40,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  );
                }

                return const SizedBox.shrink();
              },
            );
          }

          return const SizedBox.shrink();
        },
      ),
    );
  }
}
