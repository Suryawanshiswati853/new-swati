import '../../core/constants/export.dart';

class DealCard extends StatelessWidget {
  final Deal deal;
  final VoidCallback onTap;

  const DealCard({super.key, required this.deal, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(bottom: Responsive.height(context, 2)),
        padding: EdgeInsets.all(Responsive.width(context, 4)),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Theme.of(context).cardColor,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(deal.companyName, style: AppTextStyles.headline2(context)),
            SizedBox(height: Responsive.height(context, 1)),
            Text(
              'Industry: ${deal.industry}',
              style: AppTextStyles.bodyText2(context),
            ),
            Text(
              'ROI: ${deal.expectedROI.toStringAsFixed(1)}%',
              style: AppTextStyles.bodyText2(context),
            ),
            Text(
              'Investment: ₹${(deal.investmentRequired / 100000).toStringAsFixed(0)}L',
              style: AppTextStyles.bodyText2(context),
            ),
            Text(
              'Risk: ${deal.riskLevel}',
              style: AppTextStyles.bodyText2(context).copyWith(
                color: deal.riskLevel == 'Low'
                    ? AppColors.riskLow
                    : deal.riskLevel == 'Medium'
                    ? AppColors.riskMedium
                    : AppColors.riskHigh,
              ),
            ),
            Text(
              'Status: ${deal.status}',
              style: AppTextStyles.bodyText2(context).copyWith(
                color: deal.status == 'Open'
                    ? AppColors.statusOpen
                    : AppColors.statusClosed,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
