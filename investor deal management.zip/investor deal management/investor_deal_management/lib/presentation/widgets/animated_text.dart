import '../../core/constants/export.dart';

class AnimatedText extends StatefulWidget {
  final String text;
  final TextStyle? style;
  final TextAlign textAlign;
  final Duration duration;
  final Duration delay;
  final Offset beginOffset;
  final double beginScale;
  final double endScale;
  final Curve curve;
  final Color? glowColorLight;
  final Color? glowColorDark;
  final double glowRadius;
  final Color? outlineColor; // stroke colour
  final double outlineWidth; // stroke width

  const AnimatedText({
    Key? key,
    required this.text,
    this.style,
    this.textAlign = TextAlign.center,
    this.duration = const Duration(milliseconds: 700),
    this.delay = Duration.zero,
    this.beginOffset = const Offset(-0.3, 0),
    this.beginScale = 0.7,
    this.endScale = 1.0,
    this.curve = Curves.easeOutCubic,
    this.glowColorLight,
    this.glowColorDark,
    this.glowRadius = 10.0,
    this.outlineColor,
    this.outlineWidth = 2.0,
  }) : super(key: key);

  @override
  State<AnimatedText> createState() => _AnimatedTextState();
}

class _AnimatedTextState extends State<AnimatedText>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;
  late final Animation<double> _scale;
  late final Animation<double> _glowIntensity;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);
    _fade = Tween<double>(begin: 0.0, end: 1.0).animate(_controller);
    _slide = Tween<Offset>(
      begin: widget.beginOffset,
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
    _scale = Tween<double>(
      begin: widget.beginScale,
      end: widget.endScale,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
    _glowIntensity = Tween<double>(begin: 0.0, end: 1.0).animate(_controller);

    // Future.delayed(widget.delay, () {
    //   if (mounted) _controller.forward();
    // });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Replay animation if the widget becomes visible again
    if (!_controller.isAnimating && !_controller.isCompleted) {
      Future.delayed(widget.delay, () {
        if (mounted) _controller.forward();
      });
    } else if (_controller.isCompleted) {
      _controller.reset();
      Future.delayed(widget.delay, () {
        if (mounted) _controller.forward();
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _buildTextWithOutline(
    BuildContext context,
    String text,
    TextStyle baseStyle,
    TextAlign align,
    bool isOutline,
  ) {
    if (isOutline && widget.outlineColor != null) {
      // Outline text using foreground paint
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = widget.outlineWidth
        ..color = widget.outlineColor!;
      return Text(
        text,
        style: baseStyle.copyWith(
          foreground: paint,
          // Remove any fill colour if present
          color: null,
        ),
        textAlign: align,
      );
    } else {
      // Fill text
      return Text(text, style: baseStyle, textAlign: align);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final glowColor = isDark ? widget.glowColorDark : widget.glowColorLight;
    final hasGlow = glowColor != null;
    final hasOutline = widget.outlineColor != null;

    // Build the text widget (with or without glow)
    Widget buildTextWithEffects(TextStyle style, bool forOutline) {
      if (hasGlow && !forOutline) {
        return AnimatedBuilder(
          animation: _glowIntensity,
          builder: (context, child) {
            return Text(
              widget.text,
              style: style.copyWith(
                shadows: [
                  Shadow(
                    color: glowColor.withOpacity(_glowIntensity.value * 0.7),
                    blurRadius: widget.glowRadius,
                    offset: Offset.zero,
                  ),
                ],
              ),
              textAlign: widget.textAlign,
            );
          },
        );
      } else {
        return _buildTextWithOutline(
          context,
          widget.text,
          style,
          widget.textAlign,
          forOutline,
        );
      }
    }

    final baseStyle = widget.style ?? const TextStyle();
    final outlineStyle = baseStyle.copyWith(
      foreground: null,
    ); // reset foreground

    // Stack outline behind fill
    Widget content;
    if (hasOutline) {
      content = Stack(
        children: [
          // Outline layer
          buildTextWithEffects(outlineStyle, true),
          // Fill layer
          buildTextWithEffects(baseStyle, false),
        ],
      );
    } else {
      content = buildTextWithEffects(baseStyle, false);
    }

    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: ScaleTransition(scale: _scale, child: content),
      ),
    );
  }
}
