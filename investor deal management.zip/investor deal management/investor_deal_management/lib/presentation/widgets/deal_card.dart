import '../../core/constants/export.dart';

class DealCard extends StatefulWidget {
  final Deal deal;
  final VoidCallback onTap;

  const DealCard({Key? key, required this.deal, required this.onTap})
    : super(key: key);

  @override
  State<DealCard> createState() => _DealCardState();
}

class _DealCardState extends State<DealCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.2),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    // Start after first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return BlocBuilder<InterestBloc, InterestState>(
      builder: (context, interestState) {
        final isInterested =
            interestState is InterestLoaded &&
            interestState.interestedIds.contains(widget.deal.id);

        return FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Container(
              margin: EdgeInsets.symmetric(
                horizontal: Responsive.width(context, 4),
                vertical: Responsive.height(context, 1.5),
              ),
              child: GestureDetector(
                onTap: widget.onTap,
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      Responsive.width(context, 3),
                    ),
                  ),
                  child: Container(
                    padding: EdgeInsets.all(Responsive.width(context, 3)),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(
                        Responsive.width(context, 3),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? AppColors.backgroundLight.withOpacity(0.3)
                              : AppColors.backgroundDark.withOpacity(0.1),
                          blurRadius: Responsive.width(context, 2),
                          offset: Offset(0, Responsive.height(context, 0.5)),
                        ),
                      ],
                    ),

                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                widget.deal.companyName,
                                style: AppTextStyles.headline2(context)
                                    .copyWith(
                                      color: isDark
                                          ? AppColors.backgroundLight
                                          : AppColors.primaryLight,
                                    ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (isInterested)
                              Icon(
                                Icons.favorite,
                                color: AppColors.riskHigh,
                                size: Responsive.width(context, 6),
                              ),
                          ],
                        ),
                        SizedBox(height: Responsive.height(context, 1.5)),
                        Wrap(
                          spacing: Responsive.width(context, 2),
                          runSpacing: Responsive.height(context, 1),
                          children: [
                            DealChip.normal(
                              label: widget.deal.industry,
                              icon: Icons.business,
                            ),
                            DealChip.risk(label: widget.deal.riskLevel),
                            DealChip.status(label: widget.deal.status),
                          ],
                        ),
                        SizedBox(height: Responsive.height(context, 2.5)),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildInfoColumn(
                              context,
                              'Investment',
                              '₹${(widget.deal.investmentRequired / 100000).toStringAsFixed(0)}L',
                              Icons.currency_rupee_outlined,
                            ),
                            _buildInfoColumn(
                              context,
                              'Expected ROI',
                              '${widget.deal.expectedROI.toStringAsFixed(1)}%',
                              Icons.trending_up_outlined,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildInfoColumn(
    BuildContext context,
    String label,
    String value,
    IconData icon,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTextStyles.caption2(context).copyWith(
            color: isDark ? AppColors.backgroundLight : AppColors.primaryDark,
          ),
        ),
        SizedBox(height: Responsive.height(context, 1)),
        Row(
          children: [
            Icon(
              icon,
              size: Responsive.width(context, 5),
              color: AppColors.accentLight,
            ),
            SizedBox(width: Responsive.width(context, 1)),
            Text(
              value,
              style: AppTextStyles.bodyText1(
                context,
              ).copyWith(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ],
    );
  }
}
