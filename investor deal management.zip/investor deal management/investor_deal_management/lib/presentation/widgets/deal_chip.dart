import '../../core/constants/export.dart';

enum DealChipType { normal, risk, status }

class DealChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final DealChipType type;
  final Color? customColor;
  const DealChip.normal({Key? key, required this.label, required this.icon})
    : type = DealChipType.normal,
      customColor = null,
      super(key: key);

  const DealChip.risk({Key? key, required this.label})
    : type = DealChipType.risk,
      icon = Icons.warning_amber_rounded,
      customColor = null,
      super(key: key);

  const DealChip.status({Key? key, required this.label})
    : type = DealChipType.status,
      icon = Icons.check_circle_outline,
      customColor = null,
      super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color = _getChipColor(context);
    final bgColor = _getBackgroundColor(context, color);
    final effectiveIcon = type == DealChipType.status
        ? (label == 'Open' ? Icons.check_circle_outline : Icons.cancel_outlined)
        : icon;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: Responsive.width(context, 2),
        vertical: Responsive.height(context, 0.5),
      ),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(Responsive.width(context, 4)),
      ),

      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            effectiveIcon,
            size: Responsive.width(context, 6),
            color: type == DealChipType.normal
                ? (isDark ? AppColors.greyShade400 : AppColors.primaryDark)
                : color,
          ),
          SizedBox(width: Responsive.width(context, 1)),
          Text(
            label,
            style: AppTextStyles.caption2(context).copyWith(
              fontWeight: FontWeight.w600,
              color: type == DealChipType.normal ? null : color,
            ),
          ),
        ],
      ),
    );
  }

  Color _getChipColor(BuildContext context) {
    switch (type) {
      case DealChipType.risk:
        if (label == 'Low') return AppColors.riskLow;
        if (label == 'Medium') return AppColors.riskMedium;
        return AppColors.riskHigh;
      case DealChipType.status:
        return label == 'Open' ? AppColors.statusOpen : AppColors.statusClosed;
      default:
        return Theme.of(context).brightness == Brightness.dark
            ? AppColors.backgroundLight
            : Colors.grey[600]!;
    }
  }

  Color _getBackgroundColor(BuildContext context, Color color) {
    if (type == DealChipType.normal) {
      return Theme.of(context).brightness == Brightness.dark
          ? AppColors.greyShade600
          : AppColors.greyShade400;
    }
    return color.withOpacity(0.2);
  }
}
