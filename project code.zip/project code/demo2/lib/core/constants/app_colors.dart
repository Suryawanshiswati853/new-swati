import 'package:flutter/material.dart';

class AppColors {
  // Light mode colors
  static const Color lightPrimary = Color(0xFF1E88E5);
  static const Color lightSecondary = Color(0xFFFF6B6B);
  static const Color lightBackground = Color(0xFFF5F5F5);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightText = Color(0xFF1E1E2E);
  static const Color lightTextSecondary = Color(0xFF757575);

  // Dark mode colors
  static const Color darkPrimary = Color(0xFF64B5F6);
  static const Color darkSecondary = Color(0xFFFF6B6B);
  static const Color darkBackground = Color(0xFF121212);
  static const Color darkSurface = Color(0xFF1E1E2E);
  static const Color darkText = Color(0xFFFFFFFF);
  static const Color darkTextSecondary = Color(0xFFB0B0B0);

  // Category colors
  static const Color food = Color(0xFFFF9800);
  static const Color travel = Color(0xFF2196F3);
  static const Color shopping = Color(0xFF9C27B0);
  static const Color entertainment = Color(0xFF4CAF50);
  static const Color bills = Color(0xFFF44336);
  static const Color healthcare = Color(0xFF00897B);

  // Gradient colors
  static const List<Color> lightGradient = [Color(0xFF667EEA), Color(0xFF764BA2)];
  static const List<Color> darkGradient = [Color(0xFF2C3E50), Color(0xFF3498DB)];

  // Helper methods for text colors (theme-aware)
  static Color getTextColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark ? darkText : lightText;
  }

  static Color getSecondaryTextColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? darkTextSecondary
        : lightTextSecondary;
  }
}