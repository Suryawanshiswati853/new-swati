import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:demo2/core/constants/app_colors.dart';
import 'package:demo2/core/constants/utils/responsive.dart';

class AppTextStyles {
  // Headline styles
  static TextStyle headlineLarge(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 32),
        fontWeight: FontWeight.bold,
        letterSpacing: -0.5,
        color: AppColors.getTextColor(context),
      );

  static TextStyle headlineMedium(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 28),
        fontWeight: FontWeight.w600,
        color: AppColors.getTextColor(context),
      );

  static TextStyle headlineSmall(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 24),
        fontWeight: FontWeight.w600,
        color: AppColors.getTextColor(context),
      );

  // Title styles
  static TextStyle titleLarge(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 20),
        fontWeight: FontWeight.w600,
        color: AppColors.getTextColor(context),
      );

  static TextStyle titleMedium(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 18),
        fontWeight: FontWeight.w600,
        color: AppColors.getTextColor(context),
      );

  static TextStyle titleSmall(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 16),
        fontWeight: FontWeight.w600,
        color: AppColors.getTextColor(context),
      );

  // Body styles
  static TextStyle bodyLarge(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 16),
        fontWeight: FontWeight.normal,
        color: AppColors.getTextColor(context),
      );

  static TextStyle bodyMedium(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 14),
        fontWeight: FontWeight.normal,
        color: AppColors.getTextColor(context),
      );

  static TextStyle bodySmall(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 12),
        fontWeight: FontWeight.normal,
        color: AppColors.getSecondaryTextColor(context),
      );

  // Label styles
  static TextStyle labelLarge(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 14),
        fontWeight: FontWeight.w500,
        color: AppColors.getTextColor(context),
      );

  static TextStyle labelMedium(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 12),
        fontWeight: FontWeight.w500,
        color: AppColors.getTextColor(context),
      );

  static TextStyle labelSmall(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 10),
        fontWeight: FontWeight.w500,
        color: AppColors.getSecondaryTextColor(context),
      );

  // Display / monetary amount
  static TextStyle amountLarge(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 36),
        fontWeight: FontWeight.bold,
        letterSpacing: -0.5,
        color: AppColors.getTextColor(context),
      );

  static TextStyle amountMedium(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 24),
        fontWeight: FontWeight.bold,
        color: AppColors.getTextColor(context),
      );

  static TextStyle amountSmall(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 16),
        fontWeight: FontWeight.bold,
        color: AppColors.getTextColor(context),
      );

  // Category / chip text
  static TextStyle categoryChip(BuildContext context) => GoogleFonts.inter(
        fontSize: Responsive.fontSize(context, 10),
        fontWeight: FontWeight.w500,
      );

  // Override color utility
  static TextStyle withColor(TextStyle style, Color color) =>
      style.copyWith(color: color);
}