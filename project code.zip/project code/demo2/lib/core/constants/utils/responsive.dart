import 'package:flutter/material.dart';

class Responsive {
  static const double _designWidth = 375; 
  static const double _designHeight = 812;

  // Get screen dimensions
  static double width(BuildContext context) => MediaQuery.of(context).size.width;
  static double height(BuildContext context) => MediaQuery.of(context).size.height;

  // Responsive font size based on screen width
  static double fontSize(BuildContext context, double size) {
    return size * (width(context) / _designWidth);
  }

  // Responsive padding/margin
  static EdgeInsets padding({
    required BuildContext context,
    double? all,
    double? horizontal,
    double? vertical,
    double? left,
    double? top,
    double? right,
    double? bottom,
  }) {
    final scale = width(context) / _designWidth;
    return EdgeInsets.only(
      left: (left ?? horizontal ?? all ?? 0) * scale,
      top: (top ?? vertical ?? all ?? 0) * scale,
      right: (right ?? horizontal ?? all ?? 0) * scale,
      bottom: (bottom ?? vertical ?? all ?? 0) * scale,
    );
  }

  // Responsive SizedBox for spacing
  static SizedBox verticalSpace(BuildContext context, double height) =>
      SizedBox(height: height * (height / _designHeight));

  static SizedBox horizontalSpace(BuildContext context, double width) =>
      SizedBox(width: width * (Responsive.width(context) / _designWidth));

  // Screen type detection
  static bool isMobile(BuildContext context) => width(context) < 600;
  static bool isTablet(BuildContext context) => width(context) >= 600 && width(context) < 1200;
  static bool isDesktop(BuildContext context) => width(context) >= 1200;

  // Responsive value based on screen type
  static T responsiveValue<T>(BuildContext context,
      {required T mobile, T? tablet, T? desktop}) {
    if (isDesktop(context) && desktop != null) return desktop;
    if (isTablet(context) && tablet != null) return tablet;
    return mobile;
  }
}