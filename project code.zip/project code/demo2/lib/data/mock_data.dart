import 'dart:math';
import 'package:flutter/material.dart';
import 'package:demo2/models/category.dart';
import 'package:demo2/models/transaction.dart';


class MockData {
  static const int _transactionCount = 57;
  static final Random _random = Random(42);

  final List<String> _categories = [
    'Food',
    'Travel',
    'Shopping',
    'Entertainment',
    'Bills',
    'Healthcare',
  ];

  final Map<String, IconData> _categoryIcons = {
    'Food': Icons.food_bank_outlined,
    'Travel': Icons.flight_outlined,
    'Shopping': Icons.shopping_bag_outlined,
    'Entertainment': Icons.movie_outlined,
    'Bills': Icons.receipt_outlined,
    'Healthcare': Icons.health_and_safety_outlined,
  };

  final Map<String, List<String>> _descriptions = {
    'Food': ['Coffee Shop', 'Restaurant', 'Grocery Store', 'Pizza Place', 'Sushi Bar'],
    'Travel': ['Flight Ticket', 'Hotel Booking', 'Taxi Ride', 'Train Ticket', 'Car Rental'],
    'Shopping': ['Mall Purchase', 'Online Order', 'Clothing Store', 'Electronics', 'Bookstore'],
    'Entertainment': ['Movie Tickets', 'Concert', 'Netflix Subscription', 'Game Purchase', 'Amusement Park'],
    'Bills': ['Electric Bill', 'Water Bill', 'Internet Bill', 'Phone Bill', 'Gas Bill'],
    'Healthcare': ['Pharmacy', 'Doctor Visit', 'Dental Checkup', 'Medicine', 'Health Insurance'],
  };

  late List<Transaction> _transactions;

  MockData() {
    _generateMockTransactions();
  }

  void _generateMockTransactions() {
    final now = DateTime.now();
    final currentYear = now.year;

    final List<Transaction> temp = [];
    for (int i = 0; i < _transactionCount; i++) {
      final daysAgo = _random.nextInt(60);
      final date = now.subtract(Duration(days: daysAgo));
      final transactionDate = DateTime(currentYear, date.month, date.day);
      
      final category = _categories[_random.nextInt(_categories.length)];
      final descriptionList = _descriptions[category]!;
      final description = descriptionList[_random.nextInt(descriptionList.length)];
      final amount = 10 + _random.nextDouble() * 240;
      
      temp.add(Transaction(
        id: 'tx_$i',
        description: description,
        amount: double.parse(amount.toStringAsFixed(2)),
        date: transactionDate,
        category: category,
      ));
    }
    
    temp.sort((a, b) => b.date.compareTo(a.date));
    _transactions = temp;
  }

  List<Transaction> getTransactions() => _transactions;

  double getCurrentMonthTotal() {
    final now = DateTime.now();
    return _transactions
        .where((tx) => tx.date.month == now.month && tx.date.year == now.year)
        .fold(0.0, (sum, tx) => sum + tx.amount);
  }

  double getPreviousMonthTotal() {
    final now = DateTime.now();
    final previousMonth = now.month == 1 ? 12 : now.month - 1;
    final previousYear = now.month == 1 ? now.year - 1 : now.year;
    
    return _transactions
        .where((tx) => tx.date.month == previousMonth && tx.date.year == previousYear)
        .fold(0.0, (sum, tx) => sum + tx.amount); 
  }

  double getPercentageChange() {
    final currentTotal = getCurrentMonthTotal();
    final previousTotal = getPreviousMonthTotal();
    
    if (previousTotal == 0) return 0;
    return ((currentTotal - previousTotal) / previousTotal) * 100;
  }

   List<CategorySpending> getCategorySpending() {  
    final now = DateTime.now();
    final currentMonthTransactions = _transactions
        .where((tx) => tx.date.month == now.month && tx.date.year == now.year)
        .toList();
    
    return _categories.map((category) {
      final amount = currentMonthTransactions
          .where((tx) => tx.category.toLowerCase() == category.toLowerCase())
          .fold(0.0, (sum, tx) => sum + tx.amount);
      
      return CategorySpending(
        name: category,
        icon: _categoryIcons[category]!,
        amount: double.parse(amount.toStringAsFixed(2)),
      );
    }).toList();
  }
}