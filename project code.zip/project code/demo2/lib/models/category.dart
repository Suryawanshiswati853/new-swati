import 'package:flutter/material.dart';

class CategorySpending {
  final String name;
  final IconData icon;
  final double amount;

  CategorySpending({
    required this.name,
    required this.icon,
    required this.amount,
  });
}