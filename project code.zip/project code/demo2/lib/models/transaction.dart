import 'package:flutter/material.dart';
import 'package:demo2/core/constants/app_colors.dart';

class Transaction {
  final String id;
  final String description;
  final double amount;
  final DateTime date;
  final String category;

  Transaction({
    required this.id,
    required this.description,
    required this.amount,
    required this.date,
    required this.category,
  });

  IconData get categoryIcon {
    switch (category.toLowerCase()) {
      case 'food':
        return Icons.food_bank_outlined;
      case 'travel':
        return Icons.flight_outlined;
      case 'shopping':
        return Icons.shopping_bag_outlined;
      case 'entertainment':
        return Icons.movie_outlined;
      case 'bills':
        return Icons.receipt_outlined;
      case 'healthcare':
        return Icons.health_and_safety_outlined;
      default:
        return Icons.attach_money_outlined;
    }
  }

  Color get categoryColor {
    switch (category.toLowerCase()) {
      case 'food':
        return AppColors.food;
      case 'travel':
        return AppColors.travel;
      case 'shopping':
        return AppColors.shopping;
      case 'entertainment':
        return AppColors.entertainment;
      case 'bills':
        return AppColors.bills;
      case 'healthcare':
        return AppColors.healthcare;
      default:
        return Colors.grey;
    }
  }
}