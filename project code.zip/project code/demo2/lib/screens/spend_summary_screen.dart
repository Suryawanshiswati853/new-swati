import 'package:flutter/material.dart';
import 'package:demo2/data/mock_data.dart';
import 'package:demo2/models/category.dart';
import 'package:demo2/models/transaction.dart';
import 'package:demo2/widgets/header_card.dart';
import 'package:demo2/widgets/custom_appbar.dart';
import 'package:demo2/widgets/category_scroll.dart';
import 'package:demo2/core/constants/utils/responsive.dart';
import 'package:demo2/widgets/recent_transactions_list.dart';


class SpendSummaryScreen extends StatelessWidget {
  const SpendSummaryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final mockData = MockData();
    final List<Transaction> transactions = mockData.getTransactions();       
    final double monthlySpend = mockData.getCurrentMonthTotal();            
    final double percentageChange = mockData.getPercentageChange();         
    final List<CategorySpending> categories = mockData.getCategorySpending();

    return Scaffold(
      appBar: const CustomAppBar(
        title: 'Spend Summary',
      ),
    
      body: Responsive.isMobile(context)
          ? _buildMobileLayout(context, monthlySpend, percentageChange, categories, transactions)
          : _buildTabletDesktopLayout(context, monthlySpend, percentageChange, categories, transactions),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Add new transaction'),
              behavior: SnackBarBehavior.floating,
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildMobileLayout(
    BuildContext context,
    double monthlySpend,
    double percentageChange,
    List<CategorySpending> categories,  
    List<Transaction> transactions,      
  ) {
    return Column(
      children: [
        HeaderCard(totalAmount: monthlySpend, percentageChange: percentageChange),
        Responsive.verticalSpace(context, 16),
        CategoryScroll(categories: categories),
        Responsive.verticalSpace(context, 8),
        Expanded(
          child: RecentTransactionsList(transactions: transactions),
        ),
      ],
    );
  }

  Widget _buildTabletDesktopLayout(
    BuildContext context,
    double monthlySpend,
    double percentageChange,
    List<CategorySpending> categories,  
    List<Transaction> transactions,      
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 2,
          child: Column(
            children: [
              HeaderCard(totalAmount: monthlySpend, percentageChange: percentageChange),
              Responsive.verticalSpace(context, 24),
              CategoryScroll(categories: categories),
            ],
          ),
        ),
        const VerticalDivider(width: 1),
        Expanded(
          flex: 3,
          child: RecentTransactionsList(transactions: transactions),
        ),
      ],
    );
  }
}