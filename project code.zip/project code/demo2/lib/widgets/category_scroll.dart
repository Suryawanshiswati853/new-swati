import 'package:flutter/material.dart';
import 'package:demo2/models/category.dart';
import 'package:demo2/core/constants/app_colors.dart';
import 'package:demo2/core/constants/utils/responsive.dart';
import 'package:demo2/core/constants/styles/app_text_styles.dart';

class CategoryScroll extends StatelessWidget {
  final List<CategorySpending> categories;

  const CategoryScroll({super.key, required this.categories});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final itemWidth = Responsive.responsiveValue(context,
        mobile: 100.0, tablet: 120.0, desktop: 130.0);
    final itemHeight = Responsive.responsiveValue(context,
        mobile: 110.0, tablet: 120.0, desktop: 130.0);
    final iconSize = Responsive.fontSize(context, 28);

    return SizedBox(
      height: itemHeight + 20,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: Responsive.padding(context: context, horizontal: 12),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          return Container(
            width: itemWidth,
            margin: Responsive.padding(context: context, horizontal: 4),
            child: Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(Responsive.fontSize(context, 16)),
              ),
              color: isDark ? AppColors.darkSurface : AppColors.lightSurface,
              child: InkWell(
                borderRadius: BorderRadius.circular(Responsive.fontSize(context, 16)),
                onTap: () {},
                child: Padding(
                  padding: Responsive.padding(context: context, all: 12),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        category.icon,
                        size: iconSize,
                        color: Theme.of(context).primaryColor,
                      ),
                      Responsive.verticalSpace(context, 8),
                      Text(
                        category.name,
                        style: AppTextStyles.labelMedium(context),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Responsive.verticalSpace(context, 4),
                      Text(
                        '\$${category.amount.toStringAsFixed(2)}',
                        style: AppTextStyles.bodySmall(context).copyWith(
                          color: AppColors.getSecondaryTextColor(context),
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
