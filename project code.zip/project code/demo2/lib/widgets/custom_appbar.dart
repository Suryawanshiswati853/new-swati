import 'package:flutter/material.dart';
import 'package:demo2/core/constants/app_colors.dart';
import 'package:demo2/core/constants/styles/app_text_styles.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final bool centerTitle;

  const CustomAppBar({
    super.key,
    required this.title,
    this.actions,
    this.centerTitle = true,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? AppColors.darkText : AppColors.lightText;
     final backgroundColor = isDark ? AppColors.darkSurface : AppColors.lightSurface;


    return AppBar(
      title: Text(
        title,
        style: AppTextStyles.titleLarge(context).copyWith(
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
      centerTitle: centerTitle,
      elevation: 0,
      backgroundColor: backgroundColor,
      actions: actions ??
          [
            
          ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}