import 'package:flutter/material.dart';
import 'package:demo2/core/constants/app_colors.dart';
import 'package:demo2/core/constants/utils/responsive.dart';
import 'package:demo2/core/constants/styles/app_text_styles.dart';



class HeaderCard extends StatelessWidget {
  final double totalAmount;
  final double percentageChange;

  const HeaderCard({
    super.key,
    required this.totalAmount,
    required this.percentageChange,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isPositive = percentageChange >= 0;
    final changeColor = isPositive ? Colors.green : Colors.red;
    final changeIcon = isPositive ? Icons.trending_up : Icons.trending_down;
    final changeText = '${isPositive ? '+' : ''}${percentageChange.toStringAsFixed(1)}%';

    return Padding(
      padding: Responsive.padding(context: context, all: 16),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(Responsive.fontSize(context, 20)),
        ),
        child: Container(
          width: double.infinity,
          padding: Responsive.padding(context: context, all: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(Responsive.fontSize(context, 20)),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isDark ? AppColors.darkGradient : AppColors.lightGradient,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Monthly Spend',
                style: AppTextStyles.labelMedium(context).copyWith(
                  color: Colors.white70,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '\$${totalAmount.toStringAsFixed(2)}',
                style: AppTextStyles.amountLarge(context).copyWith(
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              // Use Wrap instead of Row to avoid overflow without breaking layout
              Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: changeColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(changeIcon, color: changeColor, size: 16),
                        const SizedBox(width: 4),
                        Text(
                          changeText,
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 12,
                          ).copyWith(color: changeColor),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'vs last month',
                    style: const TextStyle(fontSize: 12).copyWith(
                      color: Colors.white.withOpacity(0.7),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
// class HeaderCard extends StatelessWidget {
//   final double totalAmount;
//   final double percentageChange;

//   const HeaderCard({
//     super.key,
//     required this.totalAmount,
//     required this.percentageChange,
//   });

//   @override
//   Widget build(BuildContext context) {
//     final isDark = Theme.of(context).brightness == Brightness.dark;
//     final isPositive = percentageChange >= 0;
//     final changeColor = isPositive ? Colors.green : Colors.red;
//     final changeIcon = isPositive ? Icons.trending_up : Icons.trending_down;
//     final changeText = '${isPositive ? '+' : ''}${percentageChange.toStringAsFixed(1)}%';

//     return Padding(
//       padding: Responsive.padding(context: context, all: 16),
//       child: Card(
//         elevation: 4,
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(Responsive.fontSize(context, 20)),
//         ),
//         child: Container(
//           padding: Responsive.padding(context: context, all: 20),
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(Responsive.fontSize(context, 20)),
//             gradient: LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: isDark ? AppColors.darkGradient : AppColors.lightGradient,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 'Monthly Spend',
//                 style: AppTextStyles.labelMedium(context).copyWith(
//                   color: Colors.white70,
//                 ),
//               ),
//               Responsive.verticalSpace(context, 8),
//               Text(
//                 '\$${totalAmount.toStringAsFixed(2)}',
//                 style: AppTextStyles.amountLarge(context).copyWith(
//                   color: Colors.white,
//                 ),
//               ),
//               Responsive.verticalSpace(context, 8),
//               Row(
//                 children: [
//                   Container(
//                     padding: Responsive.padding(context: context, horizontal: 8, vertical: 4),
//                     decoration: BoxDecoration(
//                       color: changeColor.withOpacity(0.2),
//                       borderRadius: BorderRadius.circular(Responsive.fontSize(context, 12)),
//                     ),
//                     child: Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(changeIcon, color: changeColor, size: Responsive.fontSize(context, 16)),
//                         Responsive.horizontalSpace(context, 4),
//                         Text(
//                           changeText,
//                           style: AppTextStyles.labelMedium(context).copyWith(
//                             color: changeColor,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Responsive.horizontalSpace(context, 8),
//                   Text(
//                     'vs last month',
//                     style: AppTextStyles.bodySmall(context).copyWith(
//                       color: Colors.white.withOpacity(0.7),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }