import 'package:flutter/material.dart';
import 'package:demo2/models/transaction.dart';
import 'package:demo2/core/constants/app_colors.dart';
import 'package:demo2/core/constants/utils/responsive.dart';
import 'package:demo2/core/constants/styles/app_text_styles.dart';


class RecentTransactionsList extends StatelessWidget {
  final List<Transaction> transactions;

  const RecentTransactionsList({super.key, required this.transactions});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkSurface : AppColors.lightSurface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: Responsive.padding(context: context, left: 20, top: 16, right: 20, bottom: 8),
            child: Text(
              'Recent Transactions',
              style: AppTextStyles.titleMedium(context).copyWith(
                color: isDark ? AppColors.darkText : AppColors.lightText,
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: Responsive.padding(context: context, horizontal: 16),
              itemCount: transactions.length,
              itemBuilder: (context, index) {
                final transaction = transactions[index];
                return _buildTransactionItem(context, transaction);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionItem(BuildContext context, Transaction transaction) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return Padding(
      padding: Responsive.padding(context: context, vertical: 8),
      child: Row(
        children: [
          Container(
            width: Responsive.fontSize(context, 48),
            height: Responsive.fontSize(context, 48),
            decoration: BoxDecoration(
              color: transaction.categoryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(Responsive.fontSize(context, 12)),
            ),
            child: Icon(
              transaction.categoryIcon,
              color: transaction.categoryColor,
              size: Responsive.fontSize(context, 24),
            ),
          ),
          Responsive.horizontalSpace(context, 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  transaction.description,
                  style: AppTextStyles.titleSmall(context).copyWith(
                    color: AppColors.getTextColor(context),
                  ),
                ),
                Responsive.verticalSpace(context, 4),
                Row(
                  children: [
                    Text(
                      _formatDate(transaction.date),
                      style: AppTextStyles.bodySmall(context).copyWith(
                        color: AppColors.getSecondaryTextColor(context),
                      ),
                    ),
                    Responsive.horizontalSpace(context, 8),
                    Container(
                      padding: Responsive.padding(context: context, horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: transaction.categoryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(Responsive.fontSize(context, 8)),
                      ),
                      child: Text(
                        transaction.category,
                        style: AppTextStyles.categoryChip(context).copyWith(
                          color: transaction.categoryColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Text(
            '-\$${transaction.amount.toStringAsFixed(2)}',
            style: AppTextStyles.amountSmall(context).copyWith(
              color: AppColors.getTextColor(context),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final transactionDate = DateTime(date.year, date.month, date.day);

    if (transactionDate == today) {
      return 'Today';
    } else if (transactionDate == yesterday) {
      return 'Yesterday';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}
